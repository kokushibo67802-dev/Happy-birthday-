import portrait from "./assets/mrunal.jpg";
import tulips from "./assets/tulips.jpg";
import tulipsYellow from "./assets/tulips-yellow.jpg";
import lilies from "./assets/lilies.jpg";
import liliesWhite from "./assets/lilies-white.jpg";
import pastries from "./assets/pastries.jpg";
import croissants from "./assets/croissants.jpg";
import water from "./assets/water.jpg";

export const images = {
  portrait,
  tulips,
  tulipsYellow,
  lilies,
  liliesWhite,
  pastries,
  croissants,
  water,
};

export const navItems = [
  { id: "world", label: "Her little world", index: "02" },
  { id: "flowers", label: "The garden", index: "03" },
  { id: "bakes", label: "The bakery", index: "04" },
  { id: "film", label: "The film", index: "05" },
  { id: "shayari", label: "Shayari", index: "06" },
  { id: "note", label: "A note", index: "07" },
];

export type BalloonColor = "blush" | "rose" | "sage" | "gold" | "cream" | "wine" | "teal";

export const balloonPalette: Record<
  BalloonColor,
  { main: string; light: string; dark: string; label: string }
> = {
  blush: { main: "#e0a3a9", light: "#f6d3d4", dark: "#9d5661", label: "Blush" },
  rose: { main: "#bd7380", light: "#eec2c2", dark: "#7d3d4b", label: "Rose" },
  sage: { main: "#9fb29a", light: "#dbe3d1", dark: "#5d7562", label: "Sage" },
  gold: { main: "#d3aa6e", light: "#f3dfb9", dark: "#92703d", label: "Butter" },
  cream: { main: "#e9dcc4", light: "#fdf6e9", dark: "#ad9979", label: "Cream" },
  wine: { main: "#995867", light: "#d9aeb1", dark: "#5f2e3a", label: "Wine" },
  teal: { main: "#7f9f94", light: "#c8dcd3", dark: "#48645b", label: "Eucalyptus" },
};

export type BalloonSeed = {
  id: string;
  color: BalloonColor;
  wish: string;
  from: string;
  left: string;
  top: string;
  size: "sm" | "md" | "lg";
  depth: string;
  duration: string;
  delay: string;
};

export const initialBalloons: BalloonSeed[] = [
  {
    id: "wish-1",
    color: "blush",
    wish: "May your mornings be unhurried, and your water always cold and clear.",
    from: "Arush",
    left: "5%",
    top: "43%",
    size: "md",
    depth: "10px",
    duration: "7.4s",
    delay: "-0.4s",
  },
  {
    id: "wish-2",
    color: "gold",
    wish: "May something warm from the oven always find its way to your table.",
    from: "Arush",
    left: "17%",
    top: "8%",
    size: "sm",
    depth: "-30px",
    duration: "8.6s",
    delay: "-2s",
  },
  {
    id: "wish-3",
    color: "rose",
    wish: "May you be met with tulips — and the people who know why they matter.",
    from: "Arush",
    left: "28%",
    top: "46%",
    size: "lg",
    depth: "60px",
    duration: "7s",
    delay: "-1.1s",
  },
  {
    id: "wish-4",
    color: "sage",
    wish: "May this next year hand you more soft days than sharp ones.",
    from: "Arush",
    left: "44%",
    top: "9%",
    size: "md",
    depth: "0px",
    duration: "8.2s",
    delay: "-3.2s",
  },
  {
    id: "wish-5",
    color: "wine",
    wish: "May every room you walk into feel a little lighter for it.",
    from: "Arush",
    left: "54%",
    top: "48%",
    size: "lg",
    depth: "90px",
    duration: "7.8s",
    delay: "-0.8s",
  },
  {
    id: "wish-6",
    color: "cream",
    wish: "May you keep finding little things worth quoting for years.",
    from: "Arush",
    left: "70%",
    top: "6%",
    size: "sm",
    depth: "-10px",
    duration: "9s",
    delay: "-4.1s",
  },
  {
    id: "wish-7",
    color: "teal",
    wish: "And may the next chapter quietly become your favourite one yet.",
    from: "Arush",
    left: "74%",
    top: "47%",
    size: "md",
    depth: "35px",
    duration: "7.6s",
    delay: "-2.6s",
  },
];

export const addedBalloonSlots = [
  { left: "35%", top: "63%", size: "sm" as const },
  { left: "66%", top: "64%", size: "sm" as const },
  { left: "51%", top: "28%", size: "sm" as const },
];

export const littleWorld = [
  {
    id: "water",
    index: "01",
    label: "The usual",
    title: "Water, always.",
    copy: "Her favourite drink is the simplest one — clear, cold, and quietly essential. No fuss, no frills. Just the good stuff.",
    note: "h₂o, no notes",
    tone: "sage" as const,
  },
  {
    id: "bakes",
    index: "02",
    label: "From the oven",
    title: "Anything baked.",
    copy: "If it came out of an oven and is still a little warm, it already has her attention. Croissants, cinnamon, chocolate — all welcome.",
    note: "extra flaky",
    tone: "bake" as const,
  },
  {
    id: "flowers",
    index: "03",
    label: "In bloom",
    title: "Tulips, then lilies.",
    copy: "Two flowers, one soft spot. Tulips for the joy of it, lilies for the grace of it. Anything in between is simply a bonus.",
    note: "always fresh",
    tone: "blush" as const,
  },
  {
    id: "film",
    index: "04",
    label: "On repeat",
    title: "10 Things I Hate About You.",
    copy: "A sharp tongue, a soft heart, and a last line that gets everyone. The kind of film that stays with you long after the credits.",
    note: "1999, forever",
    tone: "night" as const,
  },
];

export const flowerGallery = [
  {
    id: "tulips-pink",
    src: images.tulips,
    kind: "Tulips",
    title: "The softest tulip hush",
    caption: "A window, a vase, and the kind of light that makes a room feel like a Sunday.",
    tall: true,
  },
  {
    id: "lilies-white",
    src: images.lilies,
    kind: "Lilies",
    title: "Lilies in full voice",
    caption: "All white petals and gold pollen — the quiet show-off of the flower world.",
    tall: true,
  },
  {
    id: "tulips-yellow",
    src: images.tulipsYellow,
    kind: "Tulips",
    title: "A handful of yellow",
    caption: "The flower equivalent of good news, carried home by hand.",
    tall: false,
  },
  {
    id: "lilies-bunch",
    src: images.liliesWhite,
    kind: "Lilies",
    title: "A bunch worth waiting for",
    caption: "If we could send flowers through a screen, it would be these.",
    tall: false,
  },
];

export const bakes = [
  {
    id: "croissant",
    name: "Butter croissant",
    detail: "Laminated within an inch of its life. Extra flaky, extra quiet when eaten.",
    label: "the classic",
  },
  {
    id: "cinnamon",
    name: "Cinnamon morning bun",
    detail: "Sticky at the edges, soft in the middle, best before the day properly starts.",
    label: "warm & cosy",
  },
  {
    id: "brownie",
    name: "Dark chocolate brownie",
    detail: "A crackly top, a fudgy centre, and absolutely no need to share.",
    label: "rich",
  },
  {
    id: "madeleine",
    name: "Lemon madeleine",
    detail: "Shell-shaped, golden, gone in two bites. Some things need no occasion.",
    label: "a little fancy",
  },
  {
    id: "sourdough",
    name: "Sourdough & salted butter",
    detail: "A thick slice, toasted dark, butter melting faster than you can sit down.",
    label: "simple joy",
  },
  {
    id: "blondie",
    name: "Pistachio blondie",
    detail: "Chewy, nutty, and gently over-generous. The underrated star of the box.",
    label: "the sleeper hit",
  },
];

export const tenThings = [
  { n: "01", thing: "Water, without a second thought." },
  { n: "02", thing: "Something still warm from the oven." },
  { n: "03", thing: "Tulips, in absolutely every colour." },
  { n: "04", thing: "Lilies, tall and unhurried." },
  { n: "05", thing: "A film she can quote start to finish." },
  { n: "06", thing: "The quiet confidence in her photographs." },
  { n: "07", thing: "Soft light, old songs, slow afternoons." },
  { n: "08", thing: "Mornings with nowhere to be." },
  { n: "09", thing: "People who notice the little things." },
  { n: "10", thing: "A year that is gentle with her." },
];

export const shayaris = [
  {
    id: 1,
    label: "For the girl in the photographs",
    lines: ["कभी मिले नहीं, फिर भी ये कैसा नूर है,", "तुम्हारी हर तस्वीर जैसे कोई दुआ है।"],
    translation: "We have never met, yet what is this light? Every photograph of you feels like a prayer.",
  },
  {
    id: 2,
    label: "On her smile",
    lines: ["चाँद कहता है, मुझे तारों में छुपा लो,", "तुमने जो मुस्कुरा कर ज़मीं को रोशन कर दिया।"],
    translation: "The moon says, hide me among the stars — for you smiled, and the earth grew brighter.",
  },
  {
    id: 3,
    label: "A garden in her name",
    lines: ["तेरे नाम के फूल आँगन में खिलते हैं,", "जैसे बहार ने तुम्हें अपना घर बना लिया।"],
    translation: "Flowers bloom in the courtyard at the sound of your name, as if spring has made its home in you.",
  },
  {
    id: 4,
    label: "Beauty, defined",
    lines: ["तुम्हारी तस्वीर देखी, तो लगा,", "हुस्न की कविता पूरी हुई।"],
    translation: "I looked at your photograph, and felt that the poem of beauty had found its final line.",
  },
  {
    id: 5,
    label: "A birthday prayer",
    lines: ["सालगिरह पर एक ही दुआ करते हैं,", "हर आने वाला दिन तुम्हें थोड़ा और सँवार दे।"],
    translation: "On your birthday, just one prayer: may every coming day care for you a little more.",
  },
  {
    id: 6,
    label: "No complaint, only flowers",
    lines: ["मुलाक़ात नहीं हुई, कोई गिला नहीं,", "दुआ है कि जहाँ भी हो, वहाँ फूल खिलें।"],
    translation: "We haven't met, and there is no complaint — only a wish that wherever you are, flowers bloom.",
  },
];
