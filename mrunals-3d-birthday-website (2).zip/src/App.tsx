import { useEffect, useState } from "react";
import { BalloonCelebration } from "./components/BalloonCelebration";
import { Bakes } from "./components/Bakes";
import { Film } from "./components/Film";
import { Favourites } from "./components/Favourites";
import { Flowers } from "./components/Flowers";
import { Footer } from "./components/Footer";
import { Hero } from "./components/Hero";
import { Letter } from "./components/Letter";
import { Nav } from "./components/Nav";
import { Shayari } from "./components/Shayari";
import { ArrowUpRight } from "./components/Decor";
import { useRevealOnScroll } from "./lib/hooks";

function BackToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 900);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <a
      href="#top"
      aria-label="Back to the top of the page"
      className={`fixed bottom-5 right-4 z-[60] inline-flex items-center gap-2 rounded-full border border-ink/15 bg-cream/95 px-3.5 py-2.5 text-[0.55rem] font-semibold uppercase tracking-[0.16em] text-ink/60 shadow-[0_18px_34px_-18px_rgba(29,43,37,0.55)] backdrop-blur-md transition-all duration-500 hover:border-ink/35 hover:text-ink sm:right-6 ${
        visible ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-3 opacity-0"
      }`}
    >
      <span className="grid h-6 w-6 place-items-center rounded-full bg-ink text-cream">
        <ArrowUpRight className="h-3 w-3 -rotate-45" />
      </span>
      <span className="hidden sm:inline">Back to top</span>
    </a>
  );
}

export default function App() {
  useRevealOnScroll();

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-paper">
      <a
        href="#celebrate"
        className="sr-only z-[100] rounded-full bg-ink px-5 py-3 text-sm text-cream focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
      >
        Skip to the birthday celebration
      </a>

      <div className="grain-overlay" aria-hidden="true" />

      <Nav />

      <main>
        <Hero />
        <BalloonCelebration />
        <Favourites />
        <Flowers />
        <Bakes />
        <Film />
        <Shayari />
        <Letter />
      </main>

      <Footer />
      <BackToTop />
    </div>
  );
}
