import type { CSSProperties } from "react";
import { images } from "../data";
import {
  ArrowUpRight,
  BalloonIcon,
  CroissantIcon,
  FlowerIcon,
  GlassIcon,
  Heart,
  Seal,
  Sparkle,
  TicketIcon,
  Tulip,
} from "./Decor";
import { Tape } from "./ui";

const ingredients = [
  { icon: FlowerIcon, label: "Tulips & lilies, always" },
  { icon: GlassIcon, label: "Water in a clear glass" },
  { icon: CroissantIcon, label: "Something warm from the oven" },
  { icon: TicketIcon, label: "A film with the best last line" },
];

export function Letter() {
  return (
    <section id="note" className="texture-soft relative overflow-hidden bg-paper py-20 md:py-28">
      <div
        className="pointer-events-none absolute left-1/2 top-0 h-72 w-72 -translate-x-1/2 rounded-full bg-[radial-gradient(circle,rgba(237,213,207,0.55),transparent_68%)] blur-2xl"
        aria-hidden="true"
      />
      <div className="page-shell relative">
        <div className="reveal mx-auto max-w-3xl text-center">
          <p className="eyebrow justify-center text-sage-deep">
            <span className="h-px w-8 bg-sage-deep/40" aria-hidden="true" />
            07 — From Arush
            <span className="h-px w-8 bg-sage-deep/40" aria-hidden="true" />
          </p>
          <h2 className="display mt-5 text-balance text-[clamp(2.4rem,5.2vw,4.4rem)] text-ink">
            We haven&rsquo;t met.
            <br />
            <span className="script text-rose-deep">But I hope your birthday is beautiful.</span>
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-[0.92rem] leading-8 text-muted">
            Some people deserve a little more than a message on a screen. This is that little more — a note,
            and a whole corner of the internet, for Mrunal on 14 November.
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-[1.08fr_0.92fr] lg:items-start lg:gap-8">
          {/* letter */}
          <div className="reveal relative" style={{ "--reveal-delay": "80ms" } as CSSProperties}>
            <div className="relative overflow-hidden rounded-[1.9rem] border border-ink/12 bg-cream px-6 py-8 shadow-[0_44px_90px_-60px_rgba(29,43,37,0.65)] sm:px-10 sm:py-10">
              <div
                className="pointer-events-none absolute inset-y-0 left-0 w-1 bg-[linear-gradient(to_bottom,transparent,#b9747f,transparent)] opacity-50"
                aria-hidden="true"
              />
              <div
                className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full border border-ink/10"
                aria-hidden="true"
              />

              <div className="relative flex items-start justify-between gap-5 border-b border-ink/10 pb-5">
                <div>
                  <p className="text-[0.5rem] font-bold uppercase tracking-[0.24em] text-ink/40">
                    The birthday post
                  </p>
                  <p className="mt-1.5 font-serif text-[1.1rem] italic leading-none text-ink/70">
                    delivered by hand, kept on the internet
                  </p>
                </div>
                <div className="flex shrink-0 flex-col items-center gap-1 rounded-md border border-rose-deep/30 bg-[#f6ebe2] px-3 py-2">
                  <span className="font-display text-[1.05rem] leading-none text-rose-deep">14</span>
                  <span className="text-[0.4rem] font-bold uppercase tracking-[0.18em] text-rose-deep/70">
                    nov
                  </span>
                  <FlowerIcon className="mt-0.5 h-2.5 w-2.5 text-rose-deep/50" />
                </div>
              </div>

              <div className="relative mt-7 flex flex-col gap-6 sm:flex-row sm:items-start">
                <div className="min-w-0 flex-1">
                  <p className="script text-[1.9rem] leading-none text-rose-deep">Dear Mrunal,</p>
                  <div className="mt-5 space-y-4 text-[0.9rem] leading-[1.95] text-ink/70">
                    <p>
                      We haven&rsquo;t met yet. There&rsquo;s every chance we&rsquo;ll pass each other on some
                      ordinary afternoon and never know that a little website like this ever existed.
                      That&rsquo;s okay.
                    </p>
                    <p>
                      Still, your birthday felt too lovely to let slip by without a little fuss. So I gathered
                      the things I&rsquo;ve come to admire from a distance — tulips and lilies, water in a clear
                      glass, something warm from the oven, and a film with one of the best last lines ever
                      written — and arranged them here.
                    </p>
                  </div>
                </div>

                <div className="relative mx-auto w-32 shrink-0 rotate-[4deg] rounded-sm bg-cream p-2 pb-6 shadow-[0_16px_30px_-18px_rgba(29,43,37,0.6)] ring-1 ring-ink/10 sm:w-28 lg:w-32">
                  <div className="aspect-[4/5] overflow-hidden">
                    <img
                      src={images.portrait}
                      alt="A photograph of Mrunal in a sunlit garden."
                      className="h-full w-full object-cover object-[62%_32%] saturate-[0.92]"
                      loading="lazy"
                      decoding="async"
                    />
                  </div>
                  <p className="absolute inset-x-0 bottom-1.5 text-center font-serif text-[0.72rem] italic text-ink/50">
                    the birthday girl
                  </p>
                  <Tape className="-top-2 left-1/2 w-16 -translate-x-1/2 -rotate-3 px-0 py-1" />
                </div>
              </div>

              <div className="mt-4 space-y-4 text-[0.9rem] leading-[1.95] text-ink/70">
                <p>
                  No big declarations. No expectations. Just one genuine wish: that this year is gentle with
                  you, that it brings more soft mornings than hard ones, and that there is always something
                  lovely waiting for you on the table.
                </p>
                <p className="font-serif text-[1.3rem] italic leading-snug text-ink/85">
                  Happy birthday, Mrunal. You deserve a beautiful one.
                </p>
              </div>

              <div className="mt-7 flex flex-wrap items-end justify-between gap-5 border-t border-ink/10 pt-5">
                <div>
                  <p className="text-[0.5rem] font-bold uppercase tracking-[0.2em] text-ink/35">
                    with care, and a little shyness,
                  </p>
                  <p className="script mt-1.5 text-[2.4rem] leading-none text-ink">Arush</p>
                  <p className="mt-2 text-[0.5rem] font-semibold uppercase tracking-[0.18em] text-ink/35">
                    someone who hasn&rsquo;t met you — yet
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <Tulip className="hidden h-20 w-auto -rotate-12 sm:block" />
                  <Seal className="h-12 w-12 text-[1.15rem]" />
                </div>
              </div>

              <p className="mt-5 rounded-lg bg-blush/25 px-3.5 py-2.5 font-serif text-[0.92rem] italic leading-snug text-ink/65">
                P.S. The balloons stay up until you pop them. A bit like a good wish.
              </p>
            </div>

            <div className="mt-4 flex flex-wrap items-center justify-between gap-2 px-1 text-[0.52rem] font-semibold uppercase tracking-[0.2em] text-ink/35">
              <span className="inline-flex items-center gap-1.5">
                <Sparkle className="h-2.5 w-2.5 text-rose" />
                letter no. 01 of 01
              </span>
              <span>no replies needed · no pressure</span>
            </div>
          </div>

          {/* side */}
          <div className="flex flex-col gap-4">
            <div className="reveal rounded-[1.75rem] bg-ink p-6 text-cream sm:p-7" style={{ "--reveal-delay": "140ms" } as CSSProperties}>
              <p className="eyebrow text-blush/75">
                <Heart className="h-3.5 w-3.5" />
                The honest bit
              </p>
              <h3 className="mt-3 font-display text-[1.65rem] leading-tight text-cream">
                Arush hasn&rsquo;t met Mrunal.
                <span className="script text-blush"> Not yet.</span>
              </h3>
              <p className="mt-3 text-[0.82rem] leading-7 text-cream/60">
                So this isn&rsquo;t a grand gesture with strings attached. There&rsquo;s nothing to reply to, no
                question hidden in the flowers, no expectations. Just a birthday letter, built into a
                website, because a text felt too small for the day.
              </p>
              <div className="mt-5 flex flex-wrap gap-2">
                <span className="rounded-full border border-cream/20 px-2.5 py-1 text-[0.5rem] font-semibold uppercase tracking-[0.16em] text-cream/45">
                  from a distance
                </span>
                <span className="rounded-full border border-cream/20 px-2.5 py-1 text-[0.5rem] font-semibold uppercase tracking-[0.16em] text-cream/45">
                  with respect
                </span>
                <span className="rounded-full border border-cream/20 px-2.5 py-1 text-[0.5rem] font-semibold uppercase tracking-[0.16em] text-cream/45">
                  zero pressure
                </span>
              </div>
            </div>

            <div className="reveal rounded-[1.75rem] border border-ink/10 bg-cream/70 p-6 sm:p-7" style={{ "--reveal-delay": "200ms" } as CSSProperties}>
              <div className="flex items-center justify-between gap-4">
                <p className="eyebrow text-sage-deep">
                  <Sparkle className="h-3 w-3" />
                  What this is
                </p>
                <span className="font-serif text-[0.85rem] italic text-ink/35">a small inventory</span>
              </div>
              <ul className="mt-4 space-y-2.5">
                {ingredients.map(({ icon: Icon, label }) => (
                  <li key={label} className="flex items-center gap-3 border-b border-ink/8 pb-2.5 last:border-0 last:pb-0">
                    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full border border-ink/12 bg-paper text-ink/55">
                      <Icon className="h-3.5 w-3.5" />
                    </span>
                    <span className="text-[0.8rem] leading-5 text-ink/65">{label}</span>
                    <Sparkle className="ml-auto h-2 w-2 shrink-0 text-rose/50" />
                  </li>
                ))}
              </ul>
              <p className="mt-4 font-serif text-[1rem] italic leading-snug text-ink/50">
                All of it, arranged for one day — and one person.
              </p>
            </div>

            <div className="reveal relative overflow-hidden rounded-[1.75rem] border border-ink/10 bg-blush/35 p-6 sm:p-7" style={{ "--reveal-delay": "260ms" } as CSSProperties}>
              <Tulip className="pointer-events-none absolute -bottom-8 -right-2 h-32 w-auto rotate-6 opacity-80" />
              <p className="eyebrow text-rose-deep">
                <Sparkle className="h-3 w-3" />
                One small promise
              </p>
              <p className="mt-3 max-w-[16rem] font-serif text-[1.32rem] italic leading-snug text-ink/75">
                No replies, no pressure. Just a year that treats you kindly.
              </p>
              <div className="relative z-10 mt-5 flex flex-wrap items-center gap-2.5">
                <a href="#celebrate" className="btn btn-dark btn-sm">
                  <BalloonIcon className="h-3.5 w-3.5" />
                  Add a wish
                </a>
                <a href="#top" className="btn btn-outline btn-sm">
                  Back to the top
                  <ArrowUpRight className="h-3 w-3" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
