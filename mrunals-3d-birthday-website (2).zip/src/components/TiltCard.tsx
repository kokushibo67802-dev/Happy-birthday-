import { useRef, type CSSProperties, type PointerEvent, type ReactNode } from "react";

type TiltCardProps = {
  children: ReactNode;
  className?: string;
  maxTilt?: number;
  glare?: boolean;
  style?: CSSProperties;
};

export function TiltCard({ children, className = "", maxTilt = 5, glare = true, style }: TiltCardProps) {
  const ref = useRef<HTMLDivElement>(null);

  const handleMove = (event: PointerEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el || event.pointerType === "touch") return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const rect = el.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width;
    const y = (event.clientY - rect.top) / rect.height;
    el.style.setProperty("--ry", `${(x - 0.5) * maxTilt * 2}deg`);
    el.style.setProperty("--rx", `${(0.5 - y) * maxTilt * 2}deg`);
    el.style.setProperty("--mx", `${x * 100}%`);
    el.style.setProperty("--my", `${y * 100}%`);
  };

  const handleLeave = () => {
    const el = ref.current;
    if (!el) return;
    el.style.setProperty("--ry", "0deg");
    el.style.setProperty("--rx", "0deg");
  };

  return (
    <div
      ref={ref}
      className={`tilt relative ${className}`}
      onPointerMove={handleMove}
      onPointerLeave={handleLeave}
      style={style}
    >
      {children}
      {glare ? <span className="tilt__glare" aria-hidden="true" /> : null}
    </div>
  );
}
