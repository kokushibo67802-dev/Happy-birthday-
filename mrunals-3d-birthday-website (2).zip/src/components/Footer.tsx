import { navItems } from "../data";
import {
  ArrowUpRight,
  BalloonIcon,
  CroissantIcon,
  FlowerIcon,
  GlassIcon,
  Heart,
  Monogram,
  Sparkle,
  TicketIcon,
  Tulip,
} from "./Decor";

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-ink text-cream">
      <div
        className="pointer-events-none absolute inset-0 opacity-80"
        style={{
          background:
            "radial-gradient(ellipse 50% 60% at 82% 8%, rgba(185,116,127,0.28), transparent 62%), radial-gradient(ellipse 45% 45% at 10% 95%, rgba(170,183,164,0.16), transparent 65%)",
        }}
        aria-hidden="true"
      />
      <div className="page-shell relative">
        <div className="grid gap-12 border-b border-cream/10 py-16 md:py-20 lg:grid-cols-[1.15fr_0.85fr]">
          <div>
            <p className="eyebrow text-blush/75">
              <Sparkle className="h-3.5 w-3.5" />
              One last thing, before you go
            </p>
            <h2 className="display mt-5 text-[clamp(2.7rem,6.5vw,5.4rem)] leading-[0.94] text-cream">
              Happy birthday,
              <br />
              <span className="script text-blush">Mrunal.</span>
            </h2>
            <p className="mt-5 max-w-md text-[0.9rem] leading-7 text-cream/55">
              May the year ahead be full of cold water, warm bakes, fresh flowers, and one very good film
              watched for the hundredth time. You deserve all of the soft things.
            </p>
            <div className="mt-7 flex flex-wrap items-center gap-3">
              <a href="#celebrate" className="btn btn-light">
                <BalloonIcon className="h-4 w-4" />
                Release one more wish
              </a>
              <a href="#shayari" className="btn btn-ghost-light">
                Read the shayari again
                <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
            </div>
            <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2.5 text-[0.6rem] font-semibold uppercase tracking-[0.18em] text-cream/30">
              <span className="inline-flex items-center gap-2">
                <GlassIcon className="h-3.5 w-3.5" />
                water, always
              </span>
              <span className="inline-flex items-center gap-2">
                <FlowerIcon className="h-3.5 w-3.5" />
                tulips &amp; lilies
              </span>
              <span className="inline-flex items-center gap-2">
                <CroissantIcon className="h-3.5 w-3.5" />
                something baked
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:gap-10">
            <div>
              <p className="text-[0.52rem] font-bold uppercase tracking-[0.24em] text-cream/35">
                The archive
              </p>
              <ul className="mt-4 space-y-2.5">
                {navItems.map((item) => (
                  <li key={item.id}>
                    <a
                      href={`#${item.id}`}
                      className="group inline-flex items-baseline gap-2 text-[0.8rem] text-cream/60 transition hover:text-cream"
                    >
                      <span className="font-serif text-[0.65rem] italic text-blush/45">{item.index}</span>
                      {item.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[0.52rem] font-bold uppercase tracking-[0.24em] text-cream/35">
                Little things
              </p>
              <ul className="mt-4 space-y-2.5 text-[0.8rem] text-cream/60">
                <li className="flex items-start gap-2">
                  <TicketIcon className="mt-0.5 h-3 w-3 shrink-0 text-blush/45" />
                  10 Things I Hate About You
                </li>
                <li className="flex items-start gap-2">
                  <FlowerIcon className="mt-0.5 h-3 w-3 shrink-0 text-blush/45" />
                  Tulips, then lilies
                </li>
                <li className="flex items-start gap-2">
                  <GlassIcon className="mt-0.5 h-3 w-3 shrink-0 text-blush/45" />
                  Her favourite drink: water
                </li>
                <li className="flex items-start gap-2">
                  <Heart className="mt-0.5 h-3 w-3 shrink-0 text-blush/45" />
                  Anything freshly baked
                </li>
                <li className="flex items-start gap-2">
                  <Sparkle className="mt-0.5 h-3 w-3 shrink-0 text-blush/45" />
                  14 November, celebrated properly
                </li>
              </ul>
              <div className="mt-6 border-t border-cream/10 pt-4">
                <p className="font-serif text-[1rem] italic leading-snug text-cream/50">
                  &ldquo;No replies needed. Just a lovely year ahead.&rdquo;
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-5 py-7 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
            <Monogram className="text-cream" />
            <span className="hidden h-8 w-px bg-cream/15 sm:block" />
            <p className="text-[0.58rem] font-semibold uppercase tracking-[0.16em] text-cream/30">
              Made with care by Arush
              <span className="mx-2 text-blush/40">·</span>
              for Mrunal&rsquo;s birthday
              <span className="mx-2 text-blush/40">·</span>
              no expectations
            </p>
          </div>
          <div className="flex items-center gap-4 text-[0.55rem] font-semibold uppercase tracking-[0.18em] text-cream/25">
            <span>© {new Date().getFullYear()} A small birthday archive</span>
            <a
              href="#top"
              className="inline-flex items-center gap-1.5 text-cream/40 transition hover:text-cream"
            >
              Top
              <ArrowUpRight className="h-3 w-3 -rotate-45" />
            </a>
          </div>
        </div>
      </div>

      <div className="relative overflow-hidden border-t border-cream/10">
        <div className="pointer-events-none absolute inset-0 flex items-end justify-center opacity-30" aria-hidden="true">
          <Tulip className="h-24 w-auto translate-y-8" tone="#8a5a63" toneLight="#b98a8f" />
          <Tulip
            className="mx-6 h-32 w-auto translate-y-10"
            tone="#c9828d"
            toneLight="#eec4c4"
          />
          <Tulip className="h-20 w-auto translate-y-6" tone="#8a5a63" toneLight="#b98a8f" />
        </div>
        <div className="relative z-10 flex flex-col items-center justify-center gap-2 py-6 text-center text-[0.5rem] font-semibold uppercase tracking-[0.22em] text-cream/30">
          <span className="inline-flex items-center gap-2">
            <Sparkle className="h-2.5 w-2.5 text-blush/50" />
            14 · 11 · a very good day
            <Sparkle className="h-2.5 w-2.5 text-blush/50" />
          </span>
          <span className="font-serif text-[0.9rem] font-normal italic normal-case tracking-normal text-cream/45">
            Water always. Flowers often. Bakes warm. Birthday beautiful.
          </span>
        </div>
      </div>
    </footer>
  );
}
