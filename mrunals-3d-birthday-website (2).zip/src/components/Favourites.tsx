import type { CSSProperties } from "react";
import { images } from "../data";
import {
  ArrowUpRight,
  CroissantIcon,
  FlowerIcon,
  GlassIcon,
  Heart,
  QuoteMark,
  Sparkle,
  TicketIcon,
  Tulip,
} from "./Decor";
import { SectionHeader, Tape } from "./ui";
import { TiltCard } from "./TiltCard";

const cardBase =
  "group relative flex h-full flex-col overflow-hidden rounded-[1.9rem] border border-ink/8 p-6 shadow-[0_26px_60px_-45px_rgba(29,43,37,0.5)] sm:p-7";

function CardLabel({ n, text, dark = false }: { n: string; text: string; dark?: boolean }) {
  return (
    <div
      className={`flex items-center justify-between text-[0.55rem] font-semibold uppercase tracking-[0.22em] ${
        dark ? "text-cream/45" : "text-ink/45"
      }`}
    >
      <span className="inline-flex items-center gap-2">
        <span className={`font-display text-[0.7rem] italic ${dark ? "text-blush/70" : "text-rose-deep/60"}`}>
          {n}
        </span>
        {text}
      </span>
      <span className={`h-1 w-1 rounded-full ${dark ? "bg-blush/60" : "bg-rose/60"}`} />
    </div>
  );
}

export function Favourites() {
  return (
    <section id="world" className="texture-soft relative overflow-hidden py-20 md:py-28">
      <div className="page-shell relative">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <SectionHeader
            eyebrow="02 — Her little world"
            title={
              <>
                Everything that feels
                <br />
                <span className="script text-rose-deep">like her.</span>
              </>
            }
            copy={
              <p>
                Not a grand biography — just a small, careful collection of the things she loves. The
                everyday kind of details that make a person feel like a person.
              </p>
            }
            className="max-w-2xl"
          />
          <div className="reveal hidden shrink-0 rotate-[-2.5deg] items-center gap-3 rounded-2xl border border-ink/12 bg-cream/70 px-4 py-3 text-ink/55 md:flex">
            <Sparkle className="h-3.5 w-3.5 text-rose" />
            <p className="text-[0.62rem] font-semibold uppercase leading-[1.6] tracking-[0.16em]">
              field notes
              <br />
              <span className="font-serif text-[0.85rem] font-normal italic normal-case tracking-normal text-ink/70">
                collected from a distance
              </span>
            </p>
          </div>
        </div>

        <div className="mt-12 grid gap-4 md:grid-cols-12 md:gap-5">
          {/* water */}
          <div className="reveal md:col-span-5" style={{ "--reveal-delay": "60ms" } as CSSProperties}>
            <TiltCard className="h-full" maxTilt={4}>
              <article className={`${cardBase} min-h-[21rem] bg-[#e6ebdf]`}>
                <div
                  className="pointer-events-none absolute -right-14 -top-14 h-48 w-48 rounded-full border border-ink/10"
                  aria-hidden="true"
                />
                <CardLabel n="01" text="the usual" />
                <div className="relative z-10 mt-6 pr-[35%]">
                  <span className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-ink/15 bg-cream/60 text-sage-deep">
                    <GlassIcon className="h-5 w-5" />
                  </span>
                  <h3 className="mt-5 font-display text-[2.1rem] leading-[1.02] tracking-tight text-ink">
                    Water,
                    <br />
                    always.
                  </h3>
                  <p className="mt-4 max-w-[17rem] text-[0.82rem] leading-6 text-ink/60">
                    Her favourite drink is the simplest one — clear, cold, and quietly essential. No fuss. No
                    frills. Just the good stuff.
                  </p>
                </div>
                <div className="mt-auto flex items-end justify-between gap-3 pt-6">
                  <span className="tag border-sage-deep/25 bg-cream/50 text-sage-deep">h₂o, no notes</span>
                  <div className="relative h-20 w-20 rotate-[6deg] overflow-hidden rounded-full border-[5px] border-cream shadow-[0_16px_30px_-18px_rgba(29,43,37,0.6)] sm:absolute sm:-bottom-2 sm:right-6 sm:h-28 sm:w-28">
                    <img
                      src={images.water}
                      alt="A glass of water with lemon in bright sunlight."
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                      loading="lazy"
                      decoding="async"
                    />
                  </div>
                </div>
              </article>
            </TiltCard>
          </div>

          {/* bakes */}
          <div className="reveal md:col-span-7" style={{ "--reveal-delay": "120ms" } as CSSProperties}>
            <TiltCard className="h-full" maxTilt={3}>
              <article className={`${cardBase} min-h-[21rem] bg-bake/80`}>
                <div className="relative -mx-2 -mt-2 mb-5 overflow-hidden rounded-[1.35rem] sm:absolute sm:inset-y-6 sm:right-6 sm:left-auto sm:mx-0 sm:mt-0 sm:mb-0 sm:w-[45%]">
                  <img
                    src={images.croissants}
                    alt="A tray of freshly baked croissants and pastries."
                    className="h-40 w-full object-cover transition-transform duration-700 group-hover:scale-[1.04] sm:h-full"
                    loading="lazy"
                    decoding="async"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink/25 to-transparent sm:bg-gradient-to-r" />
                  <Tape className="left-4 top-4 -rotate-3" label="fresh from the oven" />
                </div>
                <div className="relative z-10 flex h-full flex-col sm:pr-[48%]">
                  <CardLabel n="02" text="from the oven" />
                  <div className="mt-6">
                    <span className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-ink/15 bg-cream/60 text-ink/70">
                      <CroissantIcon className="h-5 w-5" />
                    </span>
                    <h3 className="mt-5 font-display text-[2.1rem] leading-[1.02] tracking-tight text-ink">
                      Anything
                      <br />
                      baked.
                    </h3>
                    <p className="mt-4 text-[0.82rem] leading-6 text-ink/60">
                      If it came out of an oven and is still a little warm, it already has her attention.
                      Croissants, cinnamon, chocolate — all welcome at the table.
                    </p>
                  </div>
                  <div className="mt-auto flex items-end justify-between gap-3 pt-6">
                    <span className="tag border-gold/35 bg-cream/50 text-gold">extra flaky</span>
                    <a
                      href="#bakes"
                      className="inline-flex items-center gap-1.5 text-[0.58rem] font-semibold uppercase tracking-[0.18em] text-ink/60 transition group-hover:text-ink"
                    >
                      The bakery
                      <ArrowUpRight className="h-3 w-3" />
                    </a>
                  </div>
                </div>
              </article>
            </TiltCard>
          </div>

          {/* flowers */}
          <div className="reveal md:col-span-7" style={{ "--reveal-delay": "180ms" } as CSSProperties}>
            <TiltCard className="h-full" maxTilt={3}>
              <article className={`${cardBase} min-h-[19rem] bg-blush/55`}>
                <Tulip className="pointer-events-none absolute -bottom-6 right-4 hidden h-48 w-auto rotate-[6deg] sm:block" />
                <div className="relative z-10 flex h-full flex-col sm:pr-[38%]">
                  <CardLabel n="03" text="in bloom" />
                  <div className="mt-6">
                    <span className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-ink/15 bg-cream/50 text-rose-deep">
                      <FlowerIcon className="h-5 w-5" />
                    </span>
                    <h3 className="mt-5 font-display text-[2.1rem] leading-[1.02] tracking-tight text-ink">
                      Tulips, then
                      <br />
                      lilies.
                    </h3>
                    <p className="mt-4 text-[0.82rem] leading-6 text-ink/60">
                      Two flowers, one soft spot. Tulips for the joy of it, lilies for the grace of it. Anything
                      in between is simply a bonus.
                    </p>
                  </div>
                  <div className="mt-auto flex items-end justify-between gap-3 pt-6">
                    <span className="tag border-rose-deep/25 bg-cream/40 text-rose-deep">always fresh</span>
                    <a
                      href="#flowers"
                      className="inline-flex items-center gap-1.5 text-[0.58rem] font-semibold uppercase tracking-[0.18em] text-ink/60 transition group-hover:text-ink"
                    >
                      The garden
                      <ArrowUpRight className="h-3 w-3" />
                    </a>
                  </div>
                </div>
                <div className="absolute bottom-5 left-1/2 flex -translate-x-1/2 items-center sm:left-auto sm:right-8 sm:translate-x-0">
                  <div className="h-16 w-16 -rotate-6 overflow-hidden rounded-full border-4 border-cream shadow-lg">
                    <img src={images.tulips} alt="" className="h-full w-full object-cover" loading="lazy" />
                  </div>
                  <div className="-ml-3 h-14 w-14 rotate-6 overflow-hidden rounded-full border-4 border-cream shadow-lg">
                    <img src={images.lilies} alt="" className="h-full w-full object-cover" loading="lazy" />
                  </div>
                </div>
              </article>
            </TiltCard>
          </div>

          {/* film */}
          <div className="reveal md:col-span-5" style={{ "--reveal-delay": "240ms" } as CSSProperties}>
            <TiltCard className="h-full" maxTilt={4}>
              <article className={`${cardBase} min-h-[19rem] border-cream/10 bg-night text-cream`}>
                <div
                  className="pointer-events-none absolute -right-6 -top-10 select-none font-display text-[10rem] leading-none text-cream/[0.05]"
                  aria-hidden="true"
                >
                  10
                </div>
                <div className="relative z-10 flex h-full flex-col">
                  <CardLabel n="04" text="on repeat" dark />
                  <div className="mt-6">
                    <span className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-cream/20 bg-cream/5 text-blush">
                      <TicketIcon className="h-5 w-5" />
                    </span>
                    <h3 className="mt-5 font-display text-[1.9rem] leading-[1.05] tracking-tight text-cream">
                      10 Things I
                      <br />
                      Hate About You.
                    </h3>
                    <p className="mt-4 text-[0.82rem] leading-6 text-cream/55">
                      A sharp tongue, a soft heart, and a last line that gets everyone. The kind of film that
                      stays long after the credits.
                    </p>
                  </div>
                  <div className="mt-auto flex items-end justify-between gap-3 pt-6">
                    <span className="inline-flex items-center gap-1.5 text-[0.56rem] font-semibold uppercase tracking-[0.18em] text-cream/40">
                      <Sparkle className="h-2.5 w-2.5 text-gold" />
                      1999, forever
                    </span>
                    <a
                      href="#film"
                      className="inline-flex items-center gap-1.5 text-[0.58rem] font-semibold uppercase tracking-[0.18em] text-blush transition hover:text-cream"
                    >
                      Take a seat
                      <ArrowUpRight className="h-3 w-3" />
                    </a>
                  </div>
                </div>
              </article>
            </TiltCard>
          </div>
        </div>

        <div className="reveal mt-10 flex flex-col items-center justify-between gap-4 border-t border-ink/10 pt-6 text-center sm:flex-row sm:text-left">
          <p className="flex items-center gap-2 font-serif text-[1.05rem] italic text-ink/55">
            <QuoteMark className="h-3.5 w-3.5 text-rose/70" />
            No grand claims. Just the little things, noticed properly.
          </p>
          <span className="text-[0.55rem] font-semibold uppercase tracking-[0.22em] text-ink/35">
            <Heart className="mr-1.5 inline h-3 w-3 text-rose" />
            filed under: the birthday girl
          </span>
        </div>
      </div>
    </section>
  );
}
