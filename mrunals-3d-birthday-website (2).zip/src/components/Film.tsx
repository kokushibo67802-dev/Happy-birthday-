import type { CSSProperties } from "react";
import { tenThings } from "../data";
import {
  ArrowUpRight,
  Heart,
  QuoteMark,
  Sparkle,
  TicketIcon,
} from "./Decor";
import { Marquee, SectionHeader } from "./ui";

function Vinyl() {
  return (
    <div className="relative h-24 w-24" aria-hidden="true">
      <div
        className="spin-slow absolute inset-0 rounded-full border border-cream/15"
        style={{
          background:
            "repeating-radial-gradient(circle at 50% 50%, #1a1211 0 2px, #241918 2px 4px, #1a1211 4px 6px)",
          boxShadow: "inset 0 0 30px rgba(0,0,0,.7), 0 12px 22px -12px rgba(0,0,0,.8)",
        }}
      >
        <div className="absolute inset-[34%] grid place-items-center rounded-full bg-gold/90 text-wine">
          <span className="font-display text-[0.5rem] italic leading-none">Mrunal</span>
          <span className="absolute h-1.5 w-1.5 rounded-full bg-wine" />
        </div>
      </div>
    </div>
  );
}

export function Film() {
  return (
    <section id="film" className="relative overflow-hidden bg-wine py-20 text-cream md:py-28">
      <div
        className="pointer-events-none absolute inset-0 opacity-80"
        style={{
          background:
            "radial-gradient(ellipse 55% 45% at 78% 12%, rgba(185,116,127,0.26), transparent 62%), radial-gradient(ellipse 45% 45% at 8% 85%, rgba(181,138,77,0.18), transparent 65%)",
        }}
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(252,249,242,.7) 1px, transparent 1px), linear-gradient(90deg, rgba(252,249,242,.7) 1px, transparent 1px)",
          backgroundSize: "68px 68px",
        }}
        aria-hidden="true"
      />

      <div className="relative">
        <div className="border-y border-cream/10 py-3 text-[0.58rem] font-semibold uppercase tracking-[0.28em] text-cream/35">
          <Marquee
            items={[
              "Now showing · for Mrunal · one night only",
              "10 Things I Hate About You",
              "A sharp tongue & a soft heart",
              "14 November · the birthday screening",
            ]}
            separator="dot"
          />
        </div>

        <div className="page-shell py-14 md:py-20">
          <div className="flex flex-col gap-10 lg:flex-row lg:items-end lg:justify-between">
            <SectionHeader
              dark
              eyebrow="05 — The film"
              title={
                <>
                  <span className="block text-[clamp(2.9rem,7.2vw,5.8rem)] leading-[0.88]">10 Things</span>
                  <span className="block text-[clamp(2.9rem,7.2vw,5.8rem)] leading-[0.92]">
                    I Hate <span className="script text-blush">About You.</span>
                  </span>
                </>
              }
              className="max-w-3xl"
            />
            <div className="reveal flex max-w-sm flex-col gap-4 lg:items-end lg:text-right">
              <div className="inline-flex items-center gap-2.5">
                <span className="h-px w-8 bg-blush/40" aria-hidden="true" />
                <span className="text-[0.58rem] font-semibold uppercase tracking-[0.24em] text-cream/45">
                  1999 · her favourite
                </span>
              </div>
              <p className="text-[0.92rem] leading-7 text-cream/60">
                A sharp tongue, a soft centre, a bet nobody needed to make, and one poem that undid an entire
                generation. Of course this one is hers.
              </p>
              <div className="flex items-center gap-1.5 text-gold">
                {[0, 1, 2, 3, 4].map((i) => (
                  <Star key={i} className="h-3 w-3" />
                ))}
                <span className="ml-2 text-[0.52rem] font-semibold uppercase tracking-[0.2em] text-cream/35">
                  a perfect last line
                </span>
              </div>
            </div>
          </div>

          <div className="mt-12 grid gap-6 lg:grid-cols-[1.04fr_0.96fr] lg:gap-8">
            {/* ticket / playbill */}
            <div className="reveal relative" style={{ "--reveal-delay": "80ms" } as CSSProperties}>
              <div className="ticket-notch relative overflow-hidden bg-[#f3e9d9] p-6 text-ink shadow-[0_50px_100px_-50px_rgba(0,0,0,0.9)] sm:p-8">
                <div className="flex items-start justify-between gap-4 border-b border-dashed border-ink/25 pb-4">
                  <div>
                    <p className="text-[0.48rem] font-bold uppercase tracking-[0.26em] text-ink/45">
                      The birthday cinema
                    </p>
                    <p className="mt-1.5 font-serif text-[1.15rem] italic leading-none text-ink/75">
                      one screening only
                    </p>
                  </div>
                  <div className="flex items-center gap-2 rounded-full border border-ink/20 px-3 py-1.5">
                    <TicketIcon className="h-3.5 w-3.5 text-rose-deep" />
                    <span className="text-[0.5rem] font-bold uppercase tracking-[0.2em] text-ink/55">
                      admit one
                    </span>
                  </div>
                </div>

                <div className="relative py-6">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-[0.5rem] font-bold uppercase tracking-[0.24em] text-rose-deep">
                        starring
                      </p>
                      <p className="mt-1 font-serif text-[1.3rem] italic leading-none text-ink/75">
                        Mrunal, in her very own year
                      </p>
                    </div>
                    <span className="font-display text-[2.6rem] leading-none text-ink/15" aria-hidden="true">
                      10
                    </span>
                  </div>

                  <h3 className="mt-5 font-display text-[clamp(2.1rem,4.4vw,3.3rem)] leading-[0.92] tracking-tight text-ink">
                    10 Things I
                    <br />
                    Hate About You<span className="text-rose-deep">.</span>
                  </h3>

                  <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 text-[0.52rem] font-bold uppercase tracking-[0.2em] text-ink/45">
                    <span>Romance · Comedy</span>
                    <span className="h-1 w-1 rounded-full bg-ink/25" />
                    <span>1999</span>
                    <span className="h-1 w-1 rounded-full bg-ink/25" />
                    <span>1h 37m</span>
                  </div>

                  <div className="relative mt-6 rounded-xl border border-ink/15 bg-cream/70 p-4">
                    <QuoteMark className="h-4 w-4 text-rose-deep/50" />
                    <p className="mt-2 font-serif text-[1.28rem] italic leading-[1.4] text-ink/85 sm:text-[1.4rem]">
                      &ldquo;I hate the way I don&rsquo;t hate you. Not even close, not even a little bit, not
                      even at all.&rdquo;
                    </p>
                    <div className="mt-3 flex items-center justify-between gap-3 border-t border-ink/10 pt-3">
                      <span className="text-[0.5rem] font-bold uppercase tracking-[0.2em] text-ink/40">
                        Kat Stratford, in the poem
                      </span>
                      <Heart className="h-3.5 w-3.5 text-rose-deep/60" aria-hidden="true" />
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-end justify-between gap-4 border-t border-dashed border-ink/25 pt-4">
                  <div className="flex gap-5">
                    <div>
                      <p className="text-[0.45rem] font-bold uppercase tracking-[0.2em] text-ink/35">date</p>
                      <p className="mt-1 font-display text-[1rem] text-ink">14.11</p>
                    </div>
                    <div>
                      <p className="text-[0.45rem] font-bold uppercase tracking-[0.2em] text-ink/35">seat</p>
                      <p className="mt-1 font-display text-[1rem] text-ink">M-01</p>
                    </div>
                    <div>
                      <p className="text-[0.45rem] font-bold uppercase tracking-[0.2em] text-ink/35">row</p>
                      <p className="mt-1 font-display text-[1rem] text-ink">Cake</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="h-7 w-20 text-ink/55 barcode" aria-hidden="true" />
                    <Vinyl />
                  </div>
                </div>

                <span className="absolute -right-10 top-24 rotate-45 bg-rose-deep px-12 py-1 text-[0.46rem] font-bold uppercase tracking-[0.24em] text-cream">
                  For Mrunal
                </span>
              </div>

              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 px-1 text-[0.52rem] font-semibold uppercase tracking-[0.2em] text-cream/35">
                <span>No poster. Just the feeling.</span>
                <span className="inline-flex items-center gap-1.5">
                  with a tall glass of water
                  <Sparkle className="h-2.5 w-2.5 text-gold" />
                </span>
              </div>
            </div>

            {/* ten things */}
            <div className="reveal relative" style={{ "--reveal-delay": "160ms" } as CSSProperties}>
              <div className="rounded-[1.75rem] border border-cream/12 bg-cream/[0.045] p-6 backdrop-blur-sm sm:p-8">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="eyebrow text-blush/75">
                      <Sparkle className="h-3 w-3" />
                      Ten things, in her honour
                    </p>
                    <h3 className="mt-3 font-display text-[1.7rem] leading-tight text-cream sm:text-[2rem]">
                      With zero hate
                      <span className="script text-blush"> this time.</span>
                    </h3>
                  </div>
                  <span className="font-display text-[2.6rem] italic leading-none text-cream/15">10</span>
                </div>

                <ul className="mt-6 grid gap-x-8 sm:grid-cols-2">
                  {tenThings.map((item) => (
                    <li key={item.n}>
                      <div className="group flex items-baseline gap-3 border-b border-cream/10 py-2.5 transition-colors hover:border-blush/40">
                        <span className="font-serif text-[0.72rem] italic text-blush/55 transition-colors group-hover:text-blush">
                          {item.n}
                        </span>
                        <span className="flex-1 text-[0.79rem] leading-5 text-cream/65 transition-colors group-hover:text-cream">
                          {item.thing}
                        </span>
                        <Sparkle className="h-2 w-2 shrink-0 text-gold/0 transition-colors group-hover:text-gold/80" />
                      </div>
                    </li>
                  ))}
                </ul>

                <p className="mt-5 max-w-sm font-serif text-[1.12rem] italic leading-snug text-cream/50">
                  &ldquo;And I hate that I can&rsquo;t be there to say happy birthday in person.&rdquo;
                  <span className="mt-1 block text-[0.55rem] font-sans font-semibold not-italic uppercase tracking-[0.18em] text-cream/30">
                    — a line Arush would probably write
                  </span>
                </p>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <a
                  href="#shayari"
                  className="group flex items-center justify-between gap-3 rounded-2xl border border-cream/12 bg-cream/[0.04] px-4 py-3.5 transition-colors hover:border-blush/30 hover:bg-cream/[0.07]"
                >
                  <span>
                    <span className="block text-[0.48rem] font-bold uppercase tracking-[0.2em] text-cream/35">
                      next
                    </span>
                    <span className="mt-1 block font-serif text-[1.05rem] italic text-cream/80">
                      some shayari for her
                    </span>
                  </span>
                  <ArrowUpRight className="h-4 w-4 shrink-0 text-blush/70 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                </a>
                <div className="flex items-center gap-3 rounded-2xl border border-cream/12 bg-gold/[0.07] px-4 py-3.5">
                  <QuoteMark className="h-4 w-4 shrink-0 text-gold/70" />
                  <p className="text-[0.7rem] leading-5 text-cream/50">
                    <span className="text-cream/80">&ldquo;I burn, I pine, I perish.&rdquo;</span> Relatable,
                    honestly.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-y border-cream/10 py-3 text-[0.58rem] font-semibold uppercase tracking-[0.26em] text-cream/25">
          <Marquee
            reverse
            items={["A very good film", "A very good birthday", "Directed by 1999", "Starring Mrunal's good taste"]}
            separator="dot"
          />
        </div>
      </div>
    </section>
  );
}

function Star({ className = "h-3 w-3" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" fill="currentColor">
      <path d="M12 2.6l2.7 6.1 6.6.6-5 4.4 1.5 6.5L12 16.8 6.2 20.2l1.5-6.5-5-4.4 6.6-.6L12 2.6Z" />
    </svg>
  );
}
