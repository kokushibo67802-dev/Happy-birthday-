import { useEffect, useState } from "react";
import { navItems } from "../data";
import { useActiveSection, useLockBody, useScrollProgress } from "../lib/hooks";
import { ArrowUpRight, BalloonIcon, CloseIcon, MenuIcon, Monogram, Sparkle } from "./Decor";

const ids = navItems.map((item) => item.id);

export function Nav() {
  const progress = useScrollProgress();
  const active = useActiveSection(ids);
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useLockBody(open);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-colors duration-500 ${
          scrolled || open
            ? "border-b border-ink/10 bg-paper/90 backdrop-blur-xl"
            : "border-b border-transparent bg-paper/40 backdrop-blur-sm"
        }`}
      >
        <div
          className="absolute inset-x-0 top-0 h-[2px] origin-left bg-rose/70 transition-transform duration-150"
          style={{ transform: `scaleX(${progress})` }}
          aria-hidden="true"
        />
        <div className="page-shell flex h-[4.6rem] items-center justify-between gap-6">
          <a href="#top" className="group shrink-0 text-ink" aria-label="Mrunal's birthday archive, back to top">
            <Monogram className="transition-opacity group-hover:opacity-80" />
          </a>

          <nav className="hidden items-center gap-1 lg:flex" aria-label="Sections">
            {navItems.map((item) => {
              const isActive = active === item.id;
              return (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  aria-current={isActive ? "true" : undefined}
                  className={`relative rounded-full px-3.5 py-2 text-[0.72rem] font-medium tracking-[0.02em] transition-colors ${
                    isActive ? "text-ink" : "text-ink/55 hover:text-ink"
                  }`}
                >
                  <span className="mr-1.5 font-display text-[0.62rem] italic opacity-50">{item.index}</span>
                  {item.label}
                  <span
                    className={`absolute inset-x-3.5 -bottom-0.5 h-px origin-left bg-rose transition-transform duration-300 ${
                      isActive ? "scale-x-100" : "scale-x-0"
                    }`}
                    aria-hidden="true"
                  />
                </a>
              );
            })}
          </nav>

          <div className="flex items-center gap-2.5">
            <span className="hidden items-center gap-2 rounded-full border border-ink/15 px-3.5 py-2 text-[0.62rem] font-semibold uppercase tracking-[0.18em] text-ink/70 md:inline-flex">
              <Sparkle className="h-3 w-3 text-rose" />
              14 Nov
            </span>
            <span className="hidden md:inline-flex">
              <a href="#celebrate" className="btn btn-dark btn-sm">
                <BalloonIcon className="h-4 w-4" />
                Make a wish
              </a>
            </span>
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              className="grid h-10 w-10 place-items-center rounded-full border border-ink/15 text-ink transition hover:bg-ink/5 lg:hidden"
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? "Close menu" : "Open menu"}
            >
              {open ? <CloseIcon className="h-4 w-4" /> : <MenuIcon className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </header>

      <div
        id="mobile-menu"
        className={`fixed inset-0 z-40 flex flex-col bg-paper pt-[4.6rem] transition-all duration-400 lg:hidden ${
          open ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0"
        }`}
        aria-hidden={!open}
      >
        <div className="page-shell flex flex-1 flex-col justify-between overflow-y-auto pb-10 pt-8">
          <nav className="flex flex-col" aria-label="Mobile sections">
            {navItems.map((item, i) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                tabIndex={open ? 0 : -1}
                onClick={() => setOpen(false)}
                style={{ transitionDelay: open ? `${60 + i * 40}ms` : "0ms" }}
                className={`group flex items-baseline justify-between border-b border-ink/10 py-4 transition-all duration-500 ${
                  open ? "translate-y-0 opacity-100" : "translate-y-3 opacity-0"
                }`}
              >
                <span className="flex items-baseline gap-4">
                  <span className="font-display text-xs italic text-rose-deep/60">{item.index}</span>
                  <span className="display text-[2rem] text-ink">{item.label}</span>
                </span>
                <ArrowUpRight className="h-4 w-4 text-ink/35 transition group-hover:text-ink" />
              </a>
            ))}
          </nav>
          <div className="mt-8 flex flex-col gap-5">
            <a
              href="#celebrate"
              onClick={() => setOpen(false)}
              tabIndex={open ? 0 : -1}
              className="btn btn-dark w-full"
            >
              <BalloonIcon className="h-4 w-4" />
              Release a birthday balloon
            </a>
            <p className="script text-center text-lg text-ink/55">
              14 November — a little celebration, made with care.
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
