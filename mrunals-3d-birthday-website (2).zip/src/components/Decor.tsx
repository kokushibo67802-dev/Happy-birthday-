import type { SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement>;

const base = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.6,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

export function ArrowUpRight({ className = "h-4 w-4", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <path d="M7 17 17 7M8 7h9v9" />
    </svg>
  );
}

export function ArrowRight({ className = "h-4 w-4", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <path d="M4 12h16M14 6l6 6-6 6" />
    </svg>
  );
}

export function ArrowLeft({ className = "h-4 w-4", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <path d="M20 12H4M10 6l-6 6 6 6" />
    </svg>
  );
}

export function ArrowDown({ className = "h-4 w-4", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <path d="M12 4v16M6 14l6 6 6-6" />
    </svg>
  );
}

export function CloseIcon({ className = "h-4 w-4", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <path d="M6 6l12 12M18 6 6 18" />
    </svg>
  );
}

export function MenuIcon({ className = "h-5 w-5", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <path d="M3 8h18M3 16h18" />
    </svg>
  );
}

export function Sparkle({ className = "h-4 w-4", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...props}>
      <path
        d="M12 2.5c.7 5.7 3.3 8.4 9 9-5.7.7-8.3 3.3-9 9-.7-5.7-3.3-8.3-9-9 5.7-.6 8.3-3.3 9-9Z"
        fill="currentColor"
      />
    </svg>
  );
}

export function Heart({ className = "h-4 w-4", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <path d="M12 20s-7.2-4.4-8.7-9A4.7 4.7 0 0 1 12 6.6 4.7 4.7 0 0 1 20.7 11c-1.5 4.6-8.7 9-8.7 9Z" />
    </svg>
  );
}

export function BalloonIcon({ className = "h-5 w-5", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <path d="M12 2.8c3.6 0 6 3 6 6.6 0 3.1-2.5 5.6-6 6.9-3.5-1.3-6-3.8-6-6.9 0-3.6 2.4-6.6 6-6.6Z" />
      <path d="M10.4 16.6h3.2L12 18.6l-1.6-2Z" fill="currentColor" stroke="none" />
      <path d="M12 18.8c-1 1.2 1.4 2 .2 3.2" />
    </svg>
  );
}

export function GlassIcon({ className = "h-5 w-5", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <path d="M6 4h12l-1.3 15.2a2 2 0 0 1-2 1.8h-5.4a2 2 0 0 1-2-1.8L6 4Z" />
      <path d="M6.5 10.5c2.6-1.3 4.6 1.3 7 .1 1.6-.8 2.8-.6 4.1-.2" />
      <path d="M8 14.2c1.9-.7 3.1.9 4.7.5" />
    </svg>
  );
}

export function CroissantIcon({ className = "h-5 w-5", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <path d="M3.3 15.7c-1-4.5 3.6-9.6 8.7-9.6s9.7 5.1 8.7 9.6" />
      <path d="M3.3 15.7c1.3 1.9 4 2.9 8.7 2.9s7.4-1 8.7-2.9" />
      <path d="M7.5 7.4 8.8 15M12 5.6v11M16.5 7.4 15.2 15" />
    </svg>
  );
}

export function FlowerIcon({ className = "h-5 w-5", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <path d="M12 21v-6.3" />
      <path d="M12 15c-3-.2-5.3-2-5.6-4.6 2.9-.3 5.2 1.5 5.6 4.6ZM12 15c3-.2 5.3-2 5.6-4.6-2.9-.3-5.2 1.5-5.6 4.6Z" />
      <path d="M12 10.5c-2.6-.7-4-2.8-4-5.1 0-1.6.8-2.9 2-3.4 1.2-.6 2.4-.2 3.2.8" />
      <path d="M12 10.5c2.6-.7 4-2.8 4-5.1 0-1.6-.8-2.9-2-3.4" />
    </svg>
  );
}

export function TicketIcon({ className = "h-5 w-5", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <path d="M3.5 8.5V6.2c0-.9.7-1.7 1.7-1.7h13.6c1 0 1.7.8 1.7 1.7v2.3a3.5 3.5 0 0 0 0 7v2.3c0 .9-.7 1.7-1.7 1.7H5.2c-1 0-1.7-.8-1.7-1.7v-2.3a3.5 3.5 0 0 0 0-7Z" />
      <path d="M14 7v10" strokeDasharray="2 2.4" />
    </svg>
  );
}

export function QuoteMark({ className = "h-5 w-5", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...props}>
      <path
        d="M9.6 5C5.9 6.6 3.7 9.4 3.7 13.1c0 3.1 1.8 5.3 4.4 5.3 2.2 0 3.9-1.6 3.9-3.8 0-2-1.4-3.5-3.3-3.5-.4 0-.8 0-1.1.2.5-1.8 1.9-3.3 3.7-4.2L9.6 5Zm9.8 0c-3.7 1.6-5.9 4.4-5.9 8.1 0 3.1 1.8 5.3 4.4 5.3 2.2 0 3.9-1.6 3.9-3.8 0-2-1.4-3.5-3.3-3.5-.4 0-.8 0-1.1.2.5-1.8 1.9-3.3 3.7-4.2L19.4 5Z"
        fill="currentColor"
      />
    </svg>
  );
}

export function Check({ className = "h-4 w-4", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <path d="m4.5 12.5 5 5L20 6.5" />
    </svg>
  );
}

export function SearchIcon({ className = "h-4 w-4", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" {...base} {...props}>
      <circle cx="11" cy="11" r="6.5" />
      <path d="m16 16 4.5 4.5" />
    </svg>
  );
}

export function Monogram({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <span className="relative grid h-9 w-9 place-items-center rounded-full border border-current/20 font-display text-[1.15rem] italic leading-none">
        M
        <span className="absolute -right-0.5 -top-0.5 h-1.5 w-1.5 rounded-full bg-rose" />
      </span>
      <span className="flex flex-col leading-none">
        <span className="font-display text-[1.05rem] tracking-tight">Mrunal</span>
        <span className="mt-1 text-[0.5rem] font-semibold uppercase tracking-[0.24em] opacity-60">
          birthday archive
        </span>
      </span>
    </span>
  );
}

/* ---------- botanical artwork ---------- */

export function Tulip({
  className = "",
  tone = "#c9828d",
  toneLight = "#ecc2c2",
  toneDeep = "#9b4f5e",
}: {
  className?: string;
  tone?: string;
  toneLight?: string;
  toneDeep?: string;
}) {
  return (
    <svg viewBox="0 0 80 150" className={className} aria-hidden="true">
      <path
        d="M40 148C39.5 118 39 96 40 62"
        fill="none"
        stroke="#6b8870"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
      <path d="M39 116C27 112 14 99 13 79C29 82 39 96 39 116Z" fill="#7c987f" />
      <path d="M41 130C54 127 68 113 70 92C54 93 42 108 41 130Z" fill="#92ab94" />
      <path d="M39 104C30 99 24 89 23 77C34 82 39 92 39 104Z" fill="#6d8a73" opacity=".8" />
      <path
        d="M17 33c0-11 8-19 15-19 3.4 0 6.3 2 8 5.4 1.7-3.4 4.6-5.4 8-5.4 7 0 15 8 15 19 0 18-9.5 32-23 36.5C26.5 65 17 51 17 33Z"
        fill={tone}
      />
      <path
        d="M32 26c0-8 2.7-13.5 8-18 5.3 4.5 8 10 8 18 0 13-3.4 23-8 28.5-4.6-5.5-8-15.5-8-28.5Z"
        fill={toneLight}
        opacity=".92"
      />
      <path
        d="M40 20v27"
        stroke={toneDeep}
        strokeWidth="1.2"
        strokeLinecap="round"
        opacity=".45"
      />
      <path
        d="M26 22c-.4 9 2 17 6.5 22"
        fill="none"
        stroke={toneDeep}
        strokeWidth="1.1"
        strokeLinecap="round"
        opacity=".32"
      />
      <path
        d="M54 22c.4 9-2 17-6.5 22"
        fill="none"
        stroke={toneDeep}
        strokeWidth="1.1"
        strokeLinecap="round"
        opacity=".32"
      />
    </svg>
  );
}

export function Lily({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 80 150" className={className} aria-hidden="true">
      <path
        d="M40 148c-.3-28-.6-48 0-74"
        fill="none"
        stroke="#718b74"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
      <path d="M39 120C28 116 18 106 16 90c13 1 22 12 23 30Z" fill="#829d86" />
      <path d="M41 134c12-3 22-13 24-29-13 1-23 12-24 29Z" fill="#96ae99" />
      <g transform="translate(40 52)">
        {[0, 60, 120, 180, 240, 300].map((deg, i) => (
          <path
            key={deg}
            d="M0 0C-10-13-10-31 0-43C10-31 10-13 0 0Z"
            fill={i % 2 === 0 ? "#fbf7ef" : "#f2e9db"}
            stroke="#d9c9b4"
            strokeWidth="1"
            transform={`rotate(${deg})`}
          />
        ))}
        <circle r="4.2" fill="#d9b46f" />
        <path d="M0 0 0-15M0 0l11-10M0 0-11-10" stroke="#b58a4d" strokeWidth="1" strokeLinecap="round" />
        <circle cy="-16" r="1.7" fill="#a8783f" />
        <circle cx="12.5" cy="-11" r="1.7" fill="#a8783f" />
        <circle cx="-12.5" cy="-11" r="1.7" fill="#a8783f" />
      </g>
      <path
        d="M28 24c4 6 8 12 12 21"
        fill="none"
        stroke="#c7b49a"
        strokeWidth="1"
        opacity=".6"
      />
    </svg>
  );
}

export function CakeSketch({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 96 96" className={className} aria-hidden="true">
      <g fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <ellipse cx="48" cy="82" rx="34" ry="5.5" />
        <path d="M18 78V58c0-2 1.6-3.6 3.6-3.6h52.8c2 0 3.6 1.6 3.6 3.6v20" />
        <path d="M18 66c4 3.6 7 3.6 11 0s7-3.6 11 0 7 3.6 11 0 7-3.6 11 0 7 3.6 11 0" />
        <path d="M26 54V42c0-2 1.6-3.6 3.6-3.6h36.8c2 0 3.6 1.6 3.6 3.6v12" />
        <path d="M26 48c4 3.4 6.5 3.4 10.5 0s6.5-3.4 10.5 0 6.5 3.4 10.5 0 6.5-3.4 10.5 0" />
        <path d="M37 38V27M48 38V23M59 38V27" />
        <path d="M37 27c-3.2-3 .8-5.6-1.6-8.6M48 23c-3.2-3.2.8-6-1.6-9M59 27c-3.2-3 .8-5.6-1.6-8.6" />
        <circle cx="37" cy="18" r="1.6" fill="currentColor" stroke="none" />
        <circle cx="48" cy="14" r="1.6" fill="currentColor" stroke="none" />
        <circle cx="59" cy="18" r="1.6" fill="currentColor" stroke="none" />
      </g>
    </svg>
  );
}

export function Seal({ className = "" }: { className?: string }) {
  return (
    <span
      className={`grid place-items-center rounded-full bg-rose-deep text-cream shadow-[inset_0_2px_6px_rgba(255,255,255,.25),0_8px_16px_-8px_rgba(60,20,28,.7)] ${className}`}
      aria-hidden="true"
    >
      <span className="font-display text-[1.1rem] italic leading-none">A</span>
    </span>
  );
}

export function Squiggle({ className = "", ...props }: IconProps) {
  return (
    <svg viewBox="0 0 240 14" className={className} aria-hidden="true" {...props}>
      <path
        d="M2 9c22-8 40 4 62-2s38 5 62-1 42 5 62-2 32 5 50 2"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function TulipGarden({ className = "" }: { className?: string }) {
  const flowers = [
    { tone: "#c9828d", toneLight: "#eec4c4" },
    { tone: "#b9747f", toneLight: "#e7b9bd" },
    { tone: "#d9b06f", toneLight: "#f4e1bb" },
    { tone: "#c9828d", toneLight: "#eec4c4" },
    { tone: "#9a5a67", toneLight: "#d7aab1" },
  ];
  return (
    <div className={`pointer-events-none flex items-end justify-center gap-2 ${className}`} aria-hidden="true">
      {flowers.map((f, i) => (
        <Tulip
          key={i}
          className="flower-sway h-28 w-auto sm:h-36 md:h-44"
          tone={f.tone}
          toneLight={f.toneLight}
        />
      ))}
    </div>
  );
}
