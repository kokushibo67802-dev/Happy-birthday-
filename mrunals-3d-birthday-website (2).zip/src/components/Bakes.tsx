import { useState, type CSSProperties } from "react";
import { bakes, images } from "../data";
import {
  ArrowUpRight,
  CakeSketch,
  Check,
  CroissantIcon,
  GlassIcon,
  Heart,
  Sparkle,
} from "./Decor";
import { SectionHeader, Tape } from "./ui";

const initialBox = ["croissant", "madeleine"];

export function Bakes() {
  const [box, setBox] = useState<string[]>(initialBox);
  const [wrapped, setWrapped] = useState(false);

  const toggle = (id: string) => {
    setWrapped(false);
    setBox((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]));
  };

  const selected = bakes.filter((bake) => box.includes(bake.id));

  return (
    <section id="bakes" className="relative overflow-hidden bg-[#f2e5d4] py-20 md:py-28">
      <div
        className="pointer-events-none absolute inset-0 opacity-70"
        style={{
          background:
            "radial-gradient(circle at 88% 8%, rgba(255,255,255,0.65), transparent 34%), radial-gradient(circle at 6% 82%, rgba(211,170,110,0.22), transparent 36%)",
        }}
        aria-hidden="true"
      />
      <div className="page-shell relative">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <SectionHeader
            eyebrow="04 — The bakery"
            title={
              <>
                All things butter,
                <br />
                <span className="script text-gold">sugar &amp; warm.</span>
              </>
            }
            copy={
              <p>
                Her favourite kind of treat doesn't need a special occasion — just an oven, a little patience,
                and somebody to eat the first one with. Here is a bakery built entirely around her.
              </p>
            }
            className="max-w-2xl"
          />
          <div className="reveal flex shrink-0 items-center gap-3 rounded-2xl border border-ink/12 bg-cream/60 px-4 py-3">
            <CroissantIcon className="h-7 w-7 text-ink/60" />
            <p className="text-[0.58rem] font-semibold uppercase leading-[1.7] tracking-[0.16em] text-ink/50">
              house rule
              <br />
              <span className="font-serif text-[0.9rem] font-normal italic normal-case tracking-normal text-ink/75">
                always take the corner piece.
              </span>
            </p>
          </div>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-[0.92fr_1.08fr] lg:gap-8">
          {/* visual */}
          <div className="reveal relative" style={{ "--reveal-delay": "80ms" } as CSSProperties}>
            <div className="relative overflow-hidden rounded-[2rem] border border-ink/10 bg-cream p-3 shadow-[0_40px_80px_-60px_rgba(70,45,20,0.55)] sm:p-4">
              <div className="relative overflow-hidden rounded-[999px_999px_1.2rem_1.2rem]">
                <img
                  src={images.croissants}
                  alt="Fresh croissants and pastries arranged on a bakery counter."
                  className="aspect-[4/4.4] w-full object-cover"
                  loading="lazy"
                  decoding="async"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/65 via-ink/5 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-5">
                  <div>
                    <p className="text-[0.5rem] font-semibold uppercase tracking-[0.22em] text-cream/70">
                      freshly baked · still warm
                    </p>
                    <p className="mt-1.5 font-serif text-[1.6rem] italic leading-none text-cream">
                      her kind of morning.
                    </p>
                  </div>
                  <Heart className="mb-1 h-4 w-4 shrink-0 text-blush" aria-hidden="true" />
                </div>
                <Tape className="left-5 top-5 -rotate-3" label="the good stuff" />
              </div>

              <div className="mt-3 grid grid-cols-[1.15fr_0.85fr] gap-3">
                <div className="overflow-hidden rounded-xl">
                  <img
                    src={images.pastries}
                    alt="A display of artisan pastries, buns and tarts."
                    className="aspect-[4/3] w-full object-cover transition-transform duration-700 hover:scale-105"
                    loading="lazy"
                    decoding="async"
                  />
                </div>
                <div className="flex flex-col justify-center rounded-xl bg-blush/40 p-3.5">
                  <CakeSketch className="h-7 w-7 text-rose-deep/70" />
                  <p className="mt-2 font-serif text-[0.95rem] italic leading-[1.25] text-ink/70">
                    best enjoyed warm, with a tall glass of water.
                  </p>
                  <GlassIcon className="mt-2 h-4 w-4 text-sage-deep/80" />
                </div>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between gap-3 px-1 text-[0.55rem] font-semibold uppercase tracking-[0.2em] text-ink/40">
              <span className="inline-flex items-center gap-2">
                <Sparkle className="h-2.5 w-2.5 text-gold" />
                the birthday spread
              </span>
              <span>no occasion needed</span>
            </div>

            <div className="absolute -left-3 top-1/2 hidden -rotate-[7deg] rounded-lg border border-ink/10 bg-cream px-3 py-2 shadow-md xl:block">
              <p className="font-serif text-[1rem] italic leading-none text-ink/75">a little of everything,</p>
              <p className="mt-1 text-[0.48rem] font-bold uppercase tracking-[0.2em] text-gold">please.</p>
            </div>
          </div>

          {/* interactive bake box */}
          <div
            className="reveal relative overflow-hidden rounded-[2rem] border border-ink/12 bg-cream p-6 shadow-[0_36px_80px_-60px_rgba(70,45,20,0.6)] sm:p-8"
            style={{ "--reveal-delay": "160ms" } as CSSProperties}
          >
            <div
              className="pointer-events-none absolute -right-12 -top-16 h-48 w-48 rounded-full border border-ink/10"
              aria-hidden="true"
            />
            <div className="relative flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="eyebrow text-gold">
                  <CroissantIcon className="h-3.5 w-3.5" />
                  The bake box
                </p>
                <h3 className="mt-3 font-display text-[1.85rem] leading-[1.05] text-ink sm:text-[2.1rem]">
                  Build her
                  <br />
                  birthday box.
                </h3>
                <p className="mt-3 max-w-sm text-[0.82rem] leading-6 text-ink/55">
                  Six warm things from the oven. Tap to add or remove — we&rsquo;ll wrap whichever ones you
                  choose. Two favourites are already in.
                </p>
              </div>
              <span className="grid h-14 w-14 shrink-0 place-items-center rounded-full border border-ink/12 bg-bake/60 text-center">
                <span className="font-display text-[1.25rem] leading-none text-ink">
                  {String(box.length).padStart(2, "0")}
                </span>
                <span className="text-[0.42rem] font-bold uppercase tracking-[0.16em] text-ink/40">picked</span>
              </span>
            </div>

            <div className="mt-5 divide-y divide-ink/10 border-y border-ink/10">
              {bakes.map((bake, index) => {
                const isIn = box.includes(bake.id);
                return (
                  <button
                    key={bake.id}
                    type="button"
                    onClick={() => toggle(bake.id)}
                    aria-pressed={isIn}
                    className="group flex w-full items-start gap-3.5 py-3.5 text-left transition-colors hover:bg-bake/25 sm:gap-4"
                  >
                    <span
                      className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md border transition-all duration-300 ${
                        isIn
                          ? "border-rose-deep bg-rose-deep text-cream"
                          : "border-ink/20 bg-transparent text-transparent group-hover:border-ink/40"
                      }`}
                      aria-hidden="true"
                    >
                      <Check className="h-3 w-3" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-0.5">
                        <span className="font-display text-[1.12rem] leading-tight text-ink">{bake.name}</span>
                        <span
                          className={`text-[0.48rem] font-semibold uppercase tracking-[0.16em] ${
                            isIn ? "text-rose-deep/70" : "text-ink/30"
                          }`}
                        >
                          {bake.label}
                        </span>
                      </span>
                      <span className="mt-1 block text-[0.76rem] leading-5 text-ink/50">{bake.detail}</span>
                    </span>
                    <span className="mt-0.5 hidden font-serif text-[0.85rem] italic text-ink/25 sm:block">
                      0{index + 1}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="mt-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="text-[0.78rem] text-ink/55">
                  In the box:{" "}
                  <span className="font-semibold text-ink">
                    {box.length ? `${box.length} of ${bakes.length}` : "nothing yet"}
                  </span>
                </p>
                {box.length > 0 ? (
                  <button
                    type="button"
                    onClick={() => {
                      setBox([]);
                      setWrapped(false);
                    }}
                    className="text-[0.55rem] font-semibold uppercase tracking-[0.18em] text-ink/35 underline decoration-ink/20 underline-offset-4 transition hover:text-ink/70"
                  >
                    clear the box
                  </button>
                ) : null}
              </div>

              <div className="mt-2.5 flex min-h-[1.6rem] flex-wrap gap-1.5">
                {selected.length ? (
                  selected.map((bake) => (
                    <span
                      key={bake.id}
                      className="rounded-full border border-ink/12 bg-bake/40 px-2.5 py-1 text-[0.55rem] font-medium text-ink/60"
                    >
                      {bake.name}
                    </span>
                  ))
                ) : (
                  <span className="text-[0.7rem] italic text-ink/35">
                    An empty box is still a promise to go to the bakery.
                  </span>
                )}
              </div>

              <div className="mt-4 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => setWrapped(true)}
                  disabled={!box.length}
                  className={`btn btn-dark ${!box.length ? "cursor-not-allowed opacity-40 hover:translate-y-0" : ""}`}
                >
                  <Heart className="h-4 w-4" />
                  Wrap her box
                </button>
                <span className="inline-flex items-center gap-2 text-[0.55rem] font-semibold uppercase tracking-[0.16em] text-ink/35">
                  <GlassIcon className="h-3.5 w-3.5" />
                  pair with water
                </span>
              </div>

              <div aria-live="polite">
                {wrapped && box.length ? (
                  <div className="wish-in ticket-notch relative mt-5 overflow-hidden rounded-xl border border-ink/15 bg-bake/60 p-4">
                    <div className="flex items-start justify-between gap-4 border-b border-dashed border-ink/20 pb-3">
                      <div>
                        <p className="text-[0.48rem] font-bold uppercase tracking-[0.22em] text-ink/40">
                          The birthday bake box
                        </p>
                        <p className="mt-1 font-serif text-[1.3rem] italic leading-none text-ink">
                          ready for Mrunal
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-[0.48rem] font-bold uppercase tracking-[0.18em] text-rose-deep">
                          box no.
                        </p>
                        <p className="font-display text-[1.2rem] leading-none text-ink">014</p>
                      </div>
                    </div>
                    <ul className="mt-3 space-y-1">
                      {selected.map((bake, i) => (
                        <li key={bake.id} className="flex items-baseline gap-2 text-[0.72rem] text-ink/65">
                          <span className="font-serif text-[0.65rem] italic text-ink/35">0{i + 1}</span>
                          {bake.name}
                        </li>
                      ))}
                    </ul>
                    <div className="mt-3 flex items-end justify-between gap-4 border-t border-dashed border-ink/20 pt-3">
                      <p className="max-w-[13rem] font-serif text-[0.85rem] italic leading-snug text-ink/55">
                        Wrap it up. Tie the string. Best paired with a tall glass of cold water.
                      </p>
                      <div className="flex items-center gap-2">
                        <span className="h-6 w-16 text-ink/50 barcode" aria-hidden="true" />
                        <span className="font-serif text-[0.7rem] italic text-ink/40">14.11</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <p className="mt-4 text-[0.65rem] leading-5 text-ink/35">
                    No preselected cake, no pressure — just the small, warm things she actually loves. Your box
                    is only a wish, not an order.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="reveal mt-14 flex flex-col items-center justify-between gap-4 rounded-2xl border border-ink/10 bg-cream/45 px-5 py-4 text-center sm:flex-row sm:text-left">
          <p className="flex items-center gap-2 font-serif text-[1.05rem] italic text-ink/60">
            <Sparkle className="h-3.5 w-3.5 text-gold" />
            &ldquo;Good bread is the most fundamentally satisfying of all foods.&rdquo;
          </p>
          <span className="inline-flex items-center gap-2 text-[0.55rem] font-semibold uppercase tracking-[0.2em] text-ink/40">
            birthday rule no. 14
            <ArrowUpRight className="h-3 w-3" />
            always say yes to seconds
          </span>
        </div>
      </div>
    </section>
  );
}
