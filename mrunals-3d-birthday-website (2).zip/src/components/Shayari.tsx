import { useState, type CSSProperties } from "react";
import { shayaris } from "../data";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Heart,
  QuoteMark,
  Seal,
  Sparkle,
  Tulip,
} from "./Decor";
import { SectionHeader } from "./ui";

export function Shayari() {
  const [active, setActive] = useState(0);
  const [copied, setCopied] = useState(false);
  const current = shayaris[active];

  const go = (direction: number) => {
    setActive((index) => (index + direction + shayaris.length) % shayaris.length);
    setCopied(false);
  };

  const copySher = async () => {
    const text = `${current.lines.join("\n")}\n\n${current.translation}\n\n— for Mrunal, on her birthday.`;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      setCopied(false);
    }
  };

  return (
    <section id="shayari" className="relative overflow-hidden bg-[#f1e3dc] py-20 md:py-28">
      <div
        className="pointer-events-none absolute inset-0 opacity-80"
        style={{
          background:
            "radial-gradient(circle at 10% 6%, rgba(255,255,255,0.65), transparent 30%), radial-gradient(circle at 92% 82%, rgba(185,116,127,0.2), transparent 38%)",
        }}
        aria-hidden="true"
      />
      <span
        className="pointer-events-none absolute -right-8 top-20 select-none font-deva text-[11rem] leading-none text-ink/[0.035] md:text-[18rem]"
        aria-hidden="true"
      >
        हुस्न
      </span>
      <span
        className="pointer-events-none absolute bottom-12 left-0 select-none font-deva text-[7rem] leading-none text-ink/[0.03] md:text-[11rem]"
        aria-hidden="true"
      >
        दुआ
      </span>

      <div className="page-shell relative">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-center lg:gap-16">
          <div>
            <SectionHeader
              eyebrow="06 — Kuch alfaaz"
              title={
                <>
                  Shayari for
                  <br />
                  <span className="script text-rose-deep">her beauty.</span>
                </>
              }
              copy={
                <p>
                  Some feelings sit better in another language. A handful of lines for Mrunal — written with
                  the shyness of a stranger and the sincerity of someone who means every word.
                </p>
              }
            />

            <div className="reveal mt-7 flex flex-wrap items-center gap-3" style={{ "--reveal-delay": "120ms" } as CSSProperties}>
              <span className="tag border-rose-deep/20 bg-cream/50 text-rose-deep">
                <Sparkle className="h-2.5 w-2.5" />
                written for her
              </span>
              <span className="tag border-sage-deep/20 bg-cream/40 text-sage-deep">
                <Heart className="h-2.5 w-2.5" />
                English below
              </span>
            </div>

            <div className="reveal mt-9 flex items-center gap-4" style={{ "--reveal-delay": "180ms" } as CSSProperties}>
              <button
                type="button"
                onClick={() => go(-1)}
                aria-label="Previous shayari"
                className="grid h-11 w-11 place-items-center rounded-full border border-ink/20 text-ink/70 transition hover:border-ink/45 hover:bg-cream/60"
              >
                <ArrowLeft className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => go(1)}
                aria-label="Next shayari"
                className="grid h-11 w-11 place-items-center rounded-full border border-ink/20 text-ink/70 transition hover:border-ink/45 hover:bg-cream/60"
              >
                <ArrowRight className="h-4 w-4" />
              </button>
              <span className="ml-1 font-serif text-[0.95rem] italic text-ink/45">
                <span className="text-ink/80">{String(active + 1).padStart(2, "0")}</span> / 0{shayaris.length}
              </span>
            </div>

            <div className="reveal mt-7 flex flex-wrap gap-2" style={{ "--reveal-delay": "220ms" } as CSSProperties}>
              {shayaris.map((sher, index) => (
                <button
                  key={sher.id}
                  type="button"
                  onClick={() => {
                    setActive(index);
                    setCopied(false);
                  }}
                  aria-label={`Read shayari ${index + 1}: ${sher.label}`}
                  aria-pressed={active === index}
                  className={`h-8 rounded-full border px-3 text-[0.52rem] font-semibold uppercase tracking-[0.14em] transition ${
                    active === index
                      ? "border-rose-deep/40 bg-rose-deep text-cream"
                      : "border-ink/15 bg-cream/30 text-ink/45 hover:border-ink/35 hover:text-ink/70"
                  }`}
                >
                  {String(index + 1).padStart(2, "0")}
                </button>
              ))}
            </div>

            <div className="reveal mt-9 flex items-start gap-4 border-t border-ink/10 pt-6" style={{ "--reveal-delay": "260ms" } as CSSProperties}>
              <Tulip className="hidden h-24 w-auto shrink-0 -rotate-6 sm:block" />
              <p className="max-w-xs font-serif text-[1.05rem] italic leading-snug text-ink/50">
                &ldquo;We haven&rsquo;t met, and there is no complaint — only a wish that wherever you are,
                flowers bloom.&rdquo;
                <span className="mt-2 block text-[0.52rem] font-sans font-semibold not-italic uppercase tracking-[0.2em] text-ink/35">
                  sher no. 06 · translated
                </span>
              </p>
            </div>
          </div>

          {/* carousel cards */}
          <div className="reveal relative" style={{ "--reveal-delay": "100ms" } as CSSProperties}>
            <div
              className="absolute inset-x-6 -bottom-3 top-6 rotate-[3deg] rounded-[1.8rem] border border-ink/10 bg-[#ead8d0]"
              aria-hidden="true"
            />
            <div
              className="absolute inset-x-3 -bottom-1.5 top-3 -rotate-[1.4deg] rounded-[1.8rem] border border-ink/10 bg-[#e8d2cb]"
              aria-hidden="true"
            />

            <div
              className="relative overflow-hidden rounded-[1.8rem] border border-ink/12 bg-cream p-6 shadow-[0_40px_80px_-55px_rgba(70,35,40,0.65)] sm:p-9"
              role="group"
              aria-roledescription="carousel"
              aria-label="Shayari written for Mrunal"
              tabIndex={0}
              onKeyDown={(event) => {
                if (event.key === "ArrowRight") go(1);
                if (event.key === "ArrowLeft") go(-1);
              }}
            >
              <div
                className="pointer-events-none absolute -right-12 -top-12 h-40 w-40 rounded-full border border-rose-deep/10"
                aria-hidden="true"
              />
              <div
                className="pointer-events-none absolute right-6 top-6 font-serif text-[5rem] italic leading-none text-rose/15"
                aria-hidden="true"
              >
                &ldquo;
              </div>

              <div className="flex items-center justify-between gap-4">
                <span className="inline-flex items-center gap-2 text-[0.52rem] font-semibold uppercase tracking-[0.2em] text-rose-deep/80">
                  <Sparkle className="h-2.5 w-2.5" />
                  {current.label}
                </span>
                <span className="font-display text-[0.85rem] italic text-ink/30">
                  {String(active + 1).padStart(2, "0")} / 0{shayaris.length}
                </span>
              </div>

              <div key={current.id} className="sher-in" aria-live="polite">
                <div className="mt-7 space-y-1.5 border-y border-ink/10 py-7 text-center">
                  {current.lines.map((line) => (
                    <p
                      key={line}
                      className="font-deva text-[clamp(1.25rem,2.5vw,1.75rem)] leading-[2.05] text-ink sm:leading-[2.1]"
                    >
                      {line}
                    </p>
                  ))}
                </div>

                <div className="mt-5 flex items-start gap-3">
                  <QuoteMark className="mt-1 h-4 w-4 shrink-0 text-rose/60" />
                  <p className="font-serif text-[1.1rem] italic leading-relaxed text-ink/60 sm:text-[1.18rem]">
                    {current.translation}
                  </p>
                </div>
              </div>

              <div className="mt-7 flex flex-wrap items-center justify-between gap-3 border-t border-ink/10 pt-4">
                <div className="flex items-center gap-2.5">
                  <Seal className="h-8 w-8 text-[0.8rem]" />
                  <span className="text-[0.5rem] font-semibold uppercase leading-[1.6] tracking-[0.16em] text-ink/40">
                    for Mrunal
                    <br />
                    <span className="font-serif text-[0.82rem] font-normal italic normal-case tracking-normal text-ink/55">
                      with respect &amp; a little shyness
                    </span>
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={copySher}
                    className="inline-flex items-center gap-1.5 rounded-full border border-ink/15 px-3 py-1.5 text-[0.5rem] font-semibold uppercase tracking-[0.14em] text-ink/50 transition hover:border-ink/35 hover:text-ink"
                  >
                    {copied ? <Check className="h-3 w-3 text-sage-deep" /> : <QuoteMark className="h-3 w-3" />}
                    {copied ? "copied" : "copy"}
                  </button>
                  <button
                    type="button"
                    onClick={() => go(1)}
                    aria-label="Next shayari"
                    className="grid h-8 w-8 place-items-center rounded-full bg-ink text-cream transition hover:bg-ink-2"
                  >
                    <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between gap-3 px-1 text-[0.52rem] font-semibold uppercase tracking-[0.2em] text-ink/35">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1 w-1 rounded-full bg-rose-deep/60" />
                use ← → to browse
              </span>
              <span>original shayari · 2026</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
