import { useEffect, useRef, useState, type CSSProperties } from "react";
import { flowerGallery } from "../data";
import { useLockBody } from "../lib/hooks";
import { ArrowUpRight, CloseIcon, FlowerIcon, Sparkle, Tulip, TulipGarden } from "./Decor";
import { SectionHeader, Tape } from "./ui";

export function Flowers() {
  const [selected, setSelected] = useState<number | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const active = selected !== null ? flowerGallery[selected] : null;

  useLockBody(selected !== null);

  useEffect(() => {
    if (selected === null) return;
    closeRef.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSelected(null);
      if (event.key === "ArrowRight") setSelected((i) => ((i ?? 0) + 1) % flowerGallery.length);
      if (event.key === "ArrowLeft") setSelected((i) => ((i ?? 0) - 1 + flowerGallery.length) % flowerGallery.length);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selected]);

  const galleryButton = (index: number, extra: string, aspect: string) => {
    const item = flowerGallery[index];
    return (
      <button
        type="button"
        onClick={() => setSelected(index)}
        aria-label={`View larger photograph: ${item.title}`}
        className={`group relative w-full overflow-hidden text-left focus-visible:outline-offset-4 ${extra}`}
      >
        <div className={`relative w-full overflow-hidden ${aspect}`}>
          <img
            src={item.src}
            alt={`${item.title} — ${item.caption}`}
            className="h-full w-full object-cover transition-transform duration-[1100ms] ease-out group-hover:scale-[1.05]"
            loading="lazy"
            decoding="async"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/55 via-ink/5 to-transparent opacity-80 transition-opacity duration-500 group-hover:opacity-95" />
          <span className="absolute left-3 top-3 inline-flex items-center gap-1.5 rounded-full border border-cream/30 bg-ink/25 px-2.5 py-1 text-[0.5rem] font-semibold uppercase tracking-[0.18em] text-cream backdrop-blur-sm">
            <FlowerIcon className="h-2.5 w-2.5" />
            {item.kind}
          </span>
          <span className="absolute right-3 top-3 grid h-7 w-7 place-items-center rounded-full border border-cream/30 bg-ink/20 text-cream opacity-0 backdrop-blur-sm transition-opacity duration-300 group-hover:opacity-100">
            <ArrowUpRight className="h-3 w-3" />
          </span>
          <span className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-4">
            <span className="font-serif text-[1.05rem] italic leading-tight text-cream/95">{item.title}</span>
          </span>
        </div>
      </button>
    );
  };

  return (
    <section id="flowers" className="relative overflow-hidden bg-[#eef0e6] py-20 md:py-28">
      <div
        className="pointer-events-none absolute inset-0 opacity-60"
        style={{
          background:
            "radial-gradient(circle at 8% 12%, rgba(185,116,127,0.14), transparent 32%), radial-gradient(circle at 92% 68%, rgba(85,112,93,0.18), transparent 38%)",
        }}
        aria-hidden="true"
      />
      <div className="page-shell relative">
        <div className="grid gap-12 lg:grid-cols-[1.02fr_0.98fr] lg:items-center lg:gap-16">
          {/* collage */}
          <div className="reveal relative order-2 lg:order-1">
            <div className="relative rounded-[2rem] border border-ink/10 bg-cream/60 p-3 shadow-[0_40px_80px_-60px_rgba(29,43,37,0.6)] sm:p-4">
              {galleryButton(0, "arch", "aspect-[16/10]")}
              <div className="mt-3 grid grid-cols-2 gap-3">
                {galleryButton(2, "rounded-2xl arch-none", "aspect-[3/4]")}
                {galleryButton(1, "rounded-2xl", "aspect-[3/4]")}
              </div>
              <div className="mt-3">{galleryButton(3, "rounded-2xl", "aspect-[16/8]")}</div>
              <Tape className="-right-3 top-6 rotate-3 sm:-right-5" label="the flower archive" />
            </div>

            <div className="absolute -left-4 bottom-20 hidden -rotate-[8deg] rounded-xl border border-ink/10 bg-cream px-4 py-3 shadow-lg sm:block">
              <p className="font-serif text-[1.1rem] italic leading-none text-ink">for Mrunal,</p>
              <p className="mt-1.5 text-[0.5rem] font-bold uppercase tracking-[0.2em] text-rose-deep">
                with all the flowers
              </p>
            </div>

            <div className="mt-5 flex items-center justify-between px-1 text-[0.55rem] font-semibold uppercase tracking-[0.2em] text-ink/40">
              <span>Four photographs, two favourites</span>
              <span className="inline-flex items-center gap-1.5">
                <Sparkle className="h-2.5 w-2.5 text-rose" />
                tap to open
              </span>
            </div>
          </div>

          {/* copy */}
          <div className="order-1 lg:order-2">
            <SectionHeader
              eyebrow="03 — The garden"
              title={
                <>
                  Tulips for joy.
                  <br />
                  <span className="script text-sage-deep">Lilies for grace.</span>
                </>
              }
              copy={
                <p>
                  Her two favourite flowers say more than we ever could. So we gathered a little garden that
                  never needs watering — soft light, quiet colour, and every petal where it should be.
                </p>
              }
            />

            <div className="reveal mt-8 space-y-3" style={{ "--reveal-delay": "120ms" } as CSSProperties}>
              <div className="group flex items-start gap-4 rounded-2xl border border-ink/10 bg-cream/60 p-4 transition-colors hover:bg-cream sm:p-5">
                <div className="grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-full bg-blush/50">
                  <Tulip className="h-16 w-auto translate-y-2" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-display text-[1.35rem] leading-none text-ink">Tulips</h3>
                    <span className="tag border-rose-deep/20 bg-blush/30 px-2 py-0.5 text-[0.5rem] text-rose-deep">
                      favourite no. 01
                    </span>
                  </div>
                  <p className="mt-2 text-[0.8rem] leading-6 text-ink/60">
                    The first sign of spring, and the easiest way to say something without saying it. Perfect
                    love, new beginnings, and the occasional yellow one that feels like good news.
                  </p>
                </div>
              </div>

              <div className="group flex items-start gap-4 rounded-2xl border border-ink/10 bg-cream/60 p-4 transition-colors hover:bg-cream sm:p-5">
                <div className="grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-full bg-[#f6f1e6] ring-1 ring-inset ring-ink/5">
                  <FlowerIcon className="h-7 w-7 text-sage-deep" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-display text-[1.35rem] leading-none text-ink">Lilies</h3>
                    <span className="tag border-sage-deep/20 bg-[#e4e9dd] px-2 py-0.5 text-[0.5rem] text-sage-deep">
                      favourite no. 02
                    </span>
                  </div>
                  <p className="mt-2 text-[0.8rem] leading-6 text-ink/60">
                    Tall, graceful, a little dramatic in the best way. Soft white petals and a scent that takes
                    over the whole room. Grace, devotion, and summer in a stem.
                  </p>
                </div>
              </div>
            </div>

            <div className="reveal mt-7 flex flex-wrap items-center gap-x-6 gap-y-4" style={{ "--reveal-delay": "200ms" } as CSSProperties}>
              <button type="button" onClick={() => setSelected(0)} className="btn btn-dark">
                <FlowerIcon className="h-4 w-4" />
                Open the flower archive
              </button>
              <p className="max-w-[13rem] font-serif text-[1.05rem] italic leading-snug text-ink/50">
                If flowers could travel through a screen, these would be at her door.
              </p>
            </div>
          </div>
        </div>

        {/* garden strip */}
        <div className="reveal relative mt-16 overflow-hidden rounded-[2rem] bg-sage-deep px-6 py-8 text-cream sm:px-10 md:py-10">
          <div
            className="pointer-events-none absolute inset-0 opacity-25"
            style={{
              background:
                "radial-gradient(circle at 78% 20%, rgba(237,213,207,0.5), transparent 45%), radial-gradient(circle at 12% 90%, rgba(255,255,255,0.25), transparent 40%)",
            }}
            aria-hidden="true"
          />
          <div className="relative z-10 flex flex-col items-center gap-6 text-center md:flex-row md:justify-between md:text-left">
            <div className="max-w-md">
              <p className="eyebrow justify-center text-blush/75 md:justify-start">
                <Sparkle className="h-3 w-3" />
                A tiny meadow
              </p>
              <h3 className="mt-3 font-display text-[1.9rem] leading-[1.05] text-cream sm:text-[2.3rem]">
                May her year bloom
                <br />
                <span className="script text-blush">exactly like this.</span>
              </h3>
              <p className="mt-3 text-[0.8rem] leading-6 text-cream/60">
                Unhurried, colourful, and full of things worth stopping for. Happy birthday, Mrunal.
              </p>
            </div>
            <TulipGarden className="-mb-14 mt-2 shrink-0 md:-mb-16 md:mt-0" />
          </div>
        </div>
      </div>

      {/* lightbox */}
      {active ? (
        <div
          className="lightbox fixed inset-0 z-[75] flex items-center justify-center bg-night/85 p-4 backdrop-blur-sm sm:p-8"
          role="dialog"
          aria-modal="true"
          aria-label={`Photograph: ${active.title}`}
          onClick={() => setSelected(null)}
        >
          <div
            className="lightbox__card relative max-h-[90vh] w-full max-w-4xl overflow-hidden rounded-2xl bg-cream shadow-2xl"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex max-h-[90vh] flex-col md:flex-row">
              <div className="relative min-h-[16rem] flex-1 bg-ink/5 md:min-h-[28rem]">
                <img
                  src={active.src}
                  alt={active.title}
                  className="h-full max-h-[52vh] w-full object-cover md:max-h-[80vh]"
                />
              </div>
              <div className="flex w-full flex-col justify-between p-6 md:w-[19rem] md:p-7">
                <div>
                  <p className="eyebrow text-sage-deep">
                    <FlowerIcon className="h-3 w-3" />
                    {active.kind}
                  </p>
                  <h3 className="mt-3 font-display text-[1.8rem] leading-[1.05] text-ink">{active.title}</h3>
                  <p className="mt-4 text-[0.82rem] leading-6 text-ink/60">{active.caption}</p>
                </div>
                <div className="mt-6 flex items-center justify-between border-t border-ink/10 pt-4">
                  <span className="text-[0.52rem] font-semibold uppercase tracking-[0.18em] text-ink/35">
                    {selected !== null ? String(selected + 1).padStart(2, "0") : ""} / 0{flowerGallery.length}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        setSelected((i) => ((i ?? 0) - 1 + flowerGallery.length) % flowerGallery.length)
                      }
                      className="grid h-8 w-8 place-items-center rounded-full border border-ink/15 text-ink/70 transition hover:bg-ink/5"
                      aria-label="Previous photograph"
                    >
                      ←
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelected((i) => ((i ?? 0) + 1) % flowerGallery.length)}
                      className="grid h-8 w-8 place-items-center rounded-full border border-ink/15 text-ink/70 transition hover:bg-ink/5"
                      aria-label="Next photograph"
                    >
                      →
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <button
              ref={closeRef}
              type="button"
              onClick={() => setSelected(null)}
              className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full border border-cream/30 bg-ink/50 text-cream backdrop-blur-md transition hover:bg-ink"
              aria-label="Close photograph"
            >
              <CloseIcon className="h-4 w-4" />
            </button>
          </div>
        </div>
      ) : null}
    </section>
  );
}
