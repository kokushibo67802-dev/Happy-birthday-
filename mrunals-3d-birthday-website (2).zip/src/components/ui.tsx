import type { CSSProperties, ReactNode } from "react";
import { Sparkle } from "./Decor";

export function SectionHeader({
  eyebrow,
  title,
  copy,
  dark = false,
  align = "left",
  className = "",
  titleClassName = "",
}: {
  eyebrow: ReactNode;
  title: ReactNode;
  copy?: ReactNode;
  dark?: boolean;
  align?: "left" | "center";
  className?: string;
  titleClassName?: string;
}) {
  return (
    <header
      className={`reveal ${align === "center" ? "mx-auto max-w-3xl text-center" : ""} ${className}`}
    >
      <div
        className={`eyebrow ${align === "center" ? "justify-center" : ""} ${
          dark ? "text-blush/80" : "text-sage-deep"
        }`}
      >
        <span className={`h-px w-8 ${dark ? "bg-blush/40" : "bg-sage-deep/40"}`} aria-hidden="true" />
        {eyebrow}
      </div>
      <h2
        className={`display mt-5 text-balance text-[clamp(2.35rem,5.1vw,4.4rem)] ${
          dark ? "text-cream" : "text-ink"
        } ${titleClassName}`}
      >
        {title}
      </h2>
      {copy ? (
        <div
          className={`mt-6 max-w-xl text-pretty text-[0.95rem] leading-8 ${
            align === "center" ? "mx-auto" : ""
          } ${dark ? "text-cream/65" : "text-muted"}`}
        >
          {copy}
        </div>
      ) : null}
    </header>
  );
}

export function Marquee({
  items,
  className = "",
  reverse = false,
  separator = "sparkle",
}: {
  items: string[];
  className?: string;
  reverse?: boolean;
  separator?: "sparkle" | "dot" | "flower";
}) {
  const content = (
    <div className="flex shrink-0 items-center">
      {items.map((item, i) => (
        <span key={`${item}-${i}`} className="flex items-center">
          <span className="whitespace-nowrap">{item}</span>
          <span className="mx-6 inline-flex opacity-60 md:mx-9" aria-hidden="true">
            {separator === "dot" ? (
              <span className="my-auto inline-block h-1.5 w-1.5 rounded-full bg-current" />
            ) : (
              <Sparkle className="h-3 w-3" />
            )}
          </span>
        </span>
      ))}
    </div>
  );

  return (
    <div className={`marquee ${reverse ? "marquee--reverse" : ""} ${className}`}>
      <div className="marquee__track">
        {content}
        <div aria-hidden="true" className="flex shrink-0 items-center">
          {content}
        </div>
      </div>
    </div>
  );
}

export function Tape({
  className = "",
  label,
  style,
}: {
  className?: string;
  label?: string;
  style?: CSSProperties;
}) {
  return (
    <span
      aria-hidden="true"
      style={style}
      className={`pointer-events-none absolute z-20 flex items-center justify-center bg-blush/70 px-4 py-1.5 font-sans text-[0.5rem] font-bold uppercase tracking-[0.24em] text-ink/55 backdrop-blur-[1px] ${className}`}
    >
      {label ?? "\u00a0"}
    </span>
  );
}

export function SmallNote({
  children,
  className = "",
  dark = false,
}: {
  children: ReactNode;
  className?: string;
  dark?: boolean;
}) {
  return (
    <p
      className={`max-w-md text-[0.7rem] leading-5 ${
        dark ? "text-cream/45" : "text-muted/90"
      } ${className}`}
    >
      {children}
    </p>
  );
}
