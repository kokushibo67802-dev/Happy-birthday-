import { useMemo, useRef, useState, type CSSProperties, type FormEvent, type PointerEvent } from "react";
import { addedBalloonSlots, balloonPalette, initialBalloons, type BalloonColor } from "../data";
import {
  ArrowUpRight,
  BalloonIcon,
  CakeSketch,
  Check,
  QuoteMark,
  Sparkle,
} from "./Decor";
import { SectionHeader } from "./ui";

type SkyBalloon = (typeof initialBalloons)[number] & { added?: boolean };

const colors: BalloonColor[] = ["blush", "rose", "gold", "sage", "teal", "cream"];

const sizeVars: Record<string, string> = {
  sm: "clamp(48px, 6.6vw, 70px)",
  md: "clamp(56px, 8.2vw, 92px)",
  lg: "clamp(62px, 9.6vw, 112px)",
};

const confettiColors = ["#edd5cf", "#c9828d", "#d3aa6e", "#aab7a4", "#fcf9f2", "#9a5a67"];

function Burst({ seed }: { seed: number }) {
  const pieces = Array.from({ length: 14 }, (_, i) => {
    const angle = (i / 14) * Math.PI * 2 + seed * 0.4;
    const distance = 60 + (i % 4) * 18;
    return {
      bx: `${Math.cos(angle) * distance}px`,
      by: `${Math.sin(angle) * distance}px`,
      br: `${(i % 2 ? 1 : -1) * (180 + i * 22)}deg`,
      color: confettiColors[i % confettiColors.length],
      width: i % 3 === 0 ? "5px" : "7px",
      height: i % 3 === 0 ? "7px" : "11px",
    };
  });

  return (
    <div className="burst" aria-hidden="true">
      {pieces.map((piece, i) => (
        <i
          key={i}
          style={
            {
              "--bx": piece.bx,
              "--by": piece.by,
              "--br": piece.br,
              "--c": piece.color,
              width: piece.width,
              height: piece.height,
              animationDelay: `${i * 12}ms`,
            } as CSSProperties
          }
        />
      ))}
    </div>
  );
}

function ConfettiRain() {
  const pieces = useMemo(
    () =>
      Array.from({ length: 46 }, (_, i) => ({
        left: `${(i * 37 + 11) % 100}%`,
        delay: `${(i % 9) * 0.09}s`,
        duration: `${2.6 + (i % 6) * 0.22}s`,
        drift: `${((i % 2 === 0 ? 1 : -1) * (18 + (i % 7) * 12)).toFixed(0)}px`,
        rotate: `${(i % 2 === 0 ? 1 : -1) * (360 + (i % 5) * 120)}deg`,
        color: confettiColors[i % confettiColors.length],
        width: i % 4 === 0 ? "5px" : "7px",
        height: i % 4 === 0 ? "9px" : "13px",
      })),
    []
  );

  return (
    <div className="confetti-rain" aria-hidden="true">
      {pieces.map((piece, i) => (
        <i
          key={i}
          style={
            {
              "--cx": piece.left,
              "--cdelay": piece.delay,
              "--cd": piece.duration,
              "--cdrift": piece.drift,
              "--crot": piece.rotate,
              "--c": piece.color,
              "--cw": piece.width,
              "--ch": piece.height,
            } as CSSProperties
          }
        />
      ))}
    </div>
  );
}

export function BalloonCelebration() {
  const [balloons, setBalloons] = useState<SkyBalloon[]>(() => [...initialBalloons]);
  const [popped, setPopped] = useState<string[]>([]);
  const [activeWish, setActiveWish] = useState<{ wish: string; from: string; id: string } | null>(null);
  const [draft, setDraft] = useState("");
  const [color, setColor] = useState<BalloonColor>("blush");
  const [status, setStatus] = useState("");
  const [rain, setRain] = useState(0);
  const stageRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);

  const released = popped.length;
  const total = balloons.length;
  const allPopped = total > 0 && released >= total;
  const progress = total ? Math.round((released / total) * 100) : 0;

  const popBalloon = (balloon: SkyBalloon, index: number) => {
    if (popped.includes(balloon.id)) return;
    setPopped((prev) => [...prev, balloon.id]);
    setActiveWish({ wish: balloon.wish, from: balloon.from, id: balloon.id });
    setStatus(`Wish ${index + 1} released into the air.`);
  };

  const releaseAll = () => {
    setPopped(balloons.map((b) => b.id));
    setRain((n) => n + 1);
    setActiveWish({
      wish: "Every balloon is up, every wish is yours. May this year be the softest one yet, Mrunal.",
      from: "Arush & everyone here",
      id: "all",
    });
    setStatus("Every wish has been released. Happy birthday, Mrunal.");
  };

  const refill = () => {
    setPopped([]);
    setActiveWish(null);
    setStatus("The sky is full again. Seven wishes, waiting for you.");
  };

  const addWish = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const wish = draft.trim();
    if (wish.length < 3) {
      setStatus("Write a few kind words first — at least a few characters.");
      return;
    }
    const customCount = balloons.filter((b) => b.added).length;
    if (customCount >= 3) {
      setStatus("The sky is beautifully full. Three wishes of your own is plenty.");
      return;
    }
    const slot = addedBalloonSlots[customCount % addedBalloonSlots.length];
    const newBalloon: SkyBalloon = {
      id: `wish-custom-${Date.now()}`,
      color,
      wish: wish.slice(0, 120),
      from: "you",
      left: slot.left,
      top: slot.top,
      size: slot.size,
      depth: "20px",
      duration: "8s",
      delay: "-0.4s",
      added: true,
    };
    setBalloons((prev) => [...prev, newBalloon]);
    setActiveWish({ wish: newBalloon.wish, from: "you", id: newBalloon.id });
    setDraft("");
    setRain((n) => n + 1);
    setStatus("Your wish is in the sky. Pop it whenever you like.");
  };

  const handleTilt = (event: PointerEvent<HTMLDivElement>) => {
    const stage = stageRef.current;
    const inner = innerRef.current;
    if (!stage || !inner || event.pointerType === "touch") return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const rect = stage.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    inner.style.transform = `rotateX(${(-y * 7).toFixed(2)}deg) rotateY(${(x * 10).toFixed(2)}deg)`;
  };

  const resetTilt = () => {
    if (innerRef.current) innerRef.current.style.transform = "rotateX(0deg) rotateY(0deg)";
  };

  return (
    <section id="celebrate" className="relative overflow-hidden bg-night text-cream">
      <div
        className="pointer-events-none absolute inset-0 opacity-70"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 72% 18%, rgba(211,170,110,0.17), transparent 65%), radial-gradient(ellipse 50% 45% at 18% 78%, rgba(185,116,127,0.2), transparent 68%), radial-gradient(ellipse 40% 35% at 50% 100%, rgba(127,159,148,0.16), transparent 70%)",
        }}
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-cream/30 to-transparent"
        aria-hidden="true"
      />
      {[
        ["12%", "16%", "0s"],
        ["82%", "30%", "1.2s"],
        ["68%", "8%", "2.4s"],
        ["28%", "66%", "1.8s"],
        ["91%", "68%", "0.6s"],
        ["48%", "4%", "3s"],
      ].map(([left, top, delay], i) => (
        <Sparkle
          key={i}
          className="twinkle pointer-events-none absolute h-2 w-2 text-cream/50"
          style={{ left, top, animationDelay: delay }}
        />
      ))}

      <div className="page-shell relative py-20 md:py-28 lg:py-32">
        <div className="flex flex-col justify-between gap-10 lg:flex-row lg:items-end">
          <SectionHeader
            dark
            eyebrow="01 — The celebration"
            title={
              <>
                Seven wishes,
                <br />
                <span className="script text-blush">into the air.</span>
              </>
            }
            copy={
              <p>
                A sky full of balloons and not one of them heavy. Tap one to set it free and read the little
                birthday wish tucked inside — or tie a wish of your own to a fresh balloon.
              </p>
            }
            className="max-w-2xl"
          />
          <div className="reveal flex items-center gap-4 rounded-2xl border border-cream/12 bg-cream/[0.04] px-5 py-4 lg:max-w-[17rem]">
            <CakeSketch className="h-12 w-12 shrink-0 text-blush/70" />
            <div>
              <p className="text-[0.55rem] font-semibold uppercase tracking-[0.22em] text-cream/45">
                Today&rsquo;s celebration
              </p>
              <p className="mt-1 font-serif text-[1.1rem] italic leading-snug text-cream/85">
                One birthday, a whole sky of good intentions.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-[0.86fr_1.14fr] lg:gap-10 xl:gap-14">
          {/* stage first on mobile */}
          <div className="relative order-1 lg:order-2">
            <div
              ref={stageRef}
              className="balloon-stage relative h-[460px] w-full sm:h-[520px] lg:h-[600px]"
              onPointerMove={handleTilt}
              onPointerLeave={resetTilt}
              aria-label="Interactive 3D balloon celebration"
            >
              <div
                className="pointer-events-none absolute inset-x-6 bottom-0 h-40 rounded-[50%] bg-[radial-gradient(ellipse,rgba(237,213,207,0.14),transparent_70%)] blur-md"
                aria-hidden="true"
              />
              <div
                className="pointer-events-none absolute inset-x-10 bottom-8 h-px bg-gradient-to-r from-transparent via-cream/20 to-transparent"
                aria-hidden="true"
              />

              <div ref={innerRef} className="balloon-stage__inner">
                {balloons.map((balloon, index) => {
                  const isPopped = popped.includes(balloon.id);
                  const palette = balloonPalette[balloon.color];
                  return (
                    <div
                      key={balloon.id}
                      className="balloon-slot"
                      style={{
                        left: balloon.left,
                        top: balloon.top,
                        zIndex: isPopped ? 1 : 10 + index,
                      }}
                    >
                      <button
                        type="button"
                        className={`balloon ${isPopped ? "is-popped" : ""}`}
                        style={
                          {
                            "--w": sizeVars[balloon.size],
                            "--z": balloon.depth,
                            "--dur": balloon.duration,
                            "--delay": balloon.delay,
                            "--b-main": palette.main,
                            "--b-light": palette.light,
                            "--b-dark": palette.dark,
                          } as CSSProperties
                        }
                        onClick={() => popBalloon(balloon, index)}
                        disabled={isPopped}
                        aria-label={
                          isPopped
                            ? "This balloon has already been released."
                            : `Pop balloon ${index + 1} to reveal a birthday wish`
                        }
                      >
                        <span className="balloon__halo" aria-hidden="true" />
                        <span className="balloon__body">
                          <span className="balloon__knot" aria-hidden="true" />
                          <span className="absolute inset-x-0 bottom-[28%] text-center font-display text-[0.7rem] tracking-[0.18em] text-cream/60">
                            {balloon.added ? "you" : String(index + 1).padStart(2, "0")}
                          </span>
                        </span>
                        <svg
                          viewBox="0 0 62 110"
                          className="balloon__string"
                          fill="none"
                          aria-hidden="true"
                        >
                          <path
                            d="M31 0c14 20-22 34-4 54s-14 32 3 52"
                            stroke="rgba(252,249,242,0.7)"
                            strokeWidth="1.1"
                          />
                        </svg>
                      </button>
                      {isPopped ? <Burst seed={index} /> : null}
                    </div>
                  );
                })}
              </div>

              <div className="pointer-events-none absolute inset-x-0 bottom-3 z-30 flex justify-center">
                <span className="inline-flex items-center gap-2 rounded-full border border-cream/15 bg-night/60 px-4 py-2 text-[0.55rem] font-semibold uppercase tracking-[0.2em] text-cream/55 backdrop-blur-sm">
                  <Sparkle className="h-2.5 w-2.5 text-gold" />
                  tap a balloon · move to tilt the sky
                </span>
              </div>

              {activeWish ? (
                <div className="absolute inset-x-3 bottom-14 z-30 lg:hidden">
                  <div key={activeWish.id} className="wish-in rounded-2xl border border-cream/15 bg-night/90 p-4 shadow-2xl backdrop-blur-md">
                    <div className="flex items-center justify-between gap-3">
                      <span className="inline-flex items-center gap-1.5 text-[0.5rem] font-semibold uppercase tracking-[0.2em] text-blush/80">
                        <BalloonIcon className="h-3 w-3" />
                        wish revealed
                      </span>
                      <span className="text-[0.5rem] uppercase tracking-[0.16em] text-cream/40">
                        from {activeWish.from}
                      </span>
                    </div>
                    <p className="mt-2 line-clamp-2 font-serif text-[1rem] italic leading-snug text-cream/90">
                      {activeWish.wish}
                    </p>
                  </div>
                </div>
              ) : null}

              {rain > 0 ? <ConfettiRain key={rain} /> : null}
            </div>

            <div className="relative z-10 mt-2 flex flex-wrap items-center justify-between gap-3 px-1 text-[0.55rem] font-semibold uppercase tracking-[0.2em] text-cream/40">
              <span className="inline-flex items-center gap-2">
                <span className="h-1 w-1 rounded-full bg-blush" />
                the sky, on her birthday
              </span>
              <span className="inline-flex items-center gap-2">
                {released} / {total} wishes released
              </span>
            </div>
          </div>

          {/* wish panel + form */}
          <div className="order-2 flex min-w-0 flex-col gap-5 lg:order-1">
            <div className="reveal relative overflow-hidden rounded-[1.75rem] border border-cream/12 bg-cream/[0.055] p-6 shadow-[0_30px_70px_-45px_rgba(0,0,0,0.9)] backdrop-blur-sm sm:p-7">
              <div
                className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full border border-cream/10"
                aria-hidden="true"
              />
              <div className="flex items-center justify-between gap-4">
                <span className="eyebrow text-blush/75">
                  <QuoteMark className="h-3.5 w-3.5" />
                  The wish inside
                </span>
                <span className="rounded-full border border-cream/15 px-2.5 py-1 font-display text-[0.65rem] italic text-cream/55">
                  {activeWish ? "opened" : "sealed"}
                </span>
              </div>

              <div className="mt-5 min-h-[168px]" aria-live="polite">
                {activeWish ? (
                  <div key={activeWish.id} className="wish-in">
                    <p className="font-serif text-[1.4rem] italic leading-[1.45] text-cream/95 sm:text-[1.55rem]">
                      &ldquo;{activeWish.wish}&rdquo;
                    </p>
                    <div className="mt-5 flex items-center gap-3">
                      <span className="h-px w-8 bg-blush/40" aria-hidden="true" />
                      <span className="text-[0.55rem] font-semibold uppercase tracking-[0.22em] text-cream/45">
                        from {activeWish.from}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="flex h-full flex-col justify-between gap-5">
                    <p className="font-serif text-[1.35rem] italic leading-[1.5] text-cream/45">
                      The sky is holding {total} wishes. Pop a balloon and let one loose.
                    </p>
                    <div className="flex items-center gap-2 text-[0.55rem] font-semibold uppercase tracking-[0.2em] text-cream/35">
                      <span className="grid h-7 w-7 place-items-center rounded-full border border-cream/15">
                        <BalloonIcon className="h-3.5 w-3.5" />
                      </span>
                      start with balloon no. 01
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-6 border-t border-cream/10 pt-5">
                <div className="flex items-center justify-between text-[0.55rem] font-semibold uppercase tracking-[0.18em] text-cream/40">
                  <span>Wishes in the air</span>
                  <span>{progress}% released</span>
                </div>
                <div className="mt-2.5 h-1 w-full overflow-hidden rounded-full bg-cream/10">
                  <div
                    className="h-full rounded-full bg-[linear-gradient(90deg,#edd5cf,#d3aa6e)] transition-[width] duration-700 ease-out"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <div className="mt-5 flex flex-wrap items-center gap-2.5">
                  {allPopped ? (
                    <button type="button" onClick={refill} className="btn btn-light btn-sm">
                      <BalloonIcon className="h-3.5 w-3.5" />
                      Fill the sky again
                    </button>
                  ) : (
                    <button type="button" onClick={releaseAll} className="btn btn-light btn-sm">
                      <Sparkle className="h-3 w-3" />
                      Release every wish
                    </button>
                  )}
                  <span className="text-[0.55rem] font-semibold uppercase tracking-[0.16em] text-cream/35">
                    {allPopped ? "and take a breath" : "go on, all at once"}
                  </span>
                </div>
              </div>
            </div>

            <form
              onSubmit={addWish}
              className="reveal rounded-[1.75rem] border border-cream/12 bg-night-2/70 p-6 sm:p-7"
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="eyebrow text-blush/75">
                    <Sparkle className="h-3 w-3" />
                    Add to the sky
                  </p>
                  <h3 className="mt-3 font-display text-[1.5rem] leading-tight text-cream">
                    Tie a wish to a balloon.
                  </h3>
                </div>
                <CakeSketch className="h-9 w-9 shrink-0 text-cream/25" />
              </div>

              <label htmlFor="wish-input" className="sr-only">
                Write a birthday wish for Mrunal
              </label>
              <div className="mt-4 rounded-xl border border-cream/15 bg-night/40 px-3.5 py-3 transition-colors focus-within:border-cream/35">
                <textarea
                  id="wish-input"
                  rows={2}
                  maxLength={120}
                  value={draft}
                  onChange={(event) => {
                    setDraft(event.target.value);
                    if (status) setStatus("");
                  }}
                  placeholder="May your year be as lovely as you are…"
                  className="w-full resize-none bg-transparent text-sm leading-6 text-cream placeholder:text-cream/30 focus:outline-none"
                />
                <div className="flex items-center justify-between">
                  <span className="text-[0.5rem] uppercase tracking-[0.16em] text-cream/30">
                    for Mrunal, on 14.11
                  </span>
                  <span className="text-[0.5rem] tabular-nums text-cream/30">{draft.length}/120</span>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2" role="group" aria-label="Choose a balloon colour">
                  {colors.map((name) => {
                    const palette = balloonPalette[name];
                    return (
                      <button
                        key={name}
                        type="button"
                        onClick={() => setColor(name)}
                        aria-label={palette.label}
                        aria-pressed={color === name}
                        className={`grid h-7 w-7 place-items-center rounded-full transition ${
                          color === name
                            ? "ring-2 ring-cream/80 ring-offset-2 ring-offset-night"
                            : "ring-1 ring-cream/20 hover:scale-105"
                        }`}
                        style={{
                          background: `radial-gradient(circle at 34% 28%, ${palette.light}, ${palette.main} 62%, ${palette.dark})`,
                        }}
                      >
                        {color === name ? <Check className="h-3 w-3 text-cream/90" /> : null}
                      </button>
                    );
                  })}
                </div>
                <button type="submit" className="btn btn-dark btn-sm">
                  Send it up
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </button>
              </div>

              <div className="mt-4 flex min-h-[1rem] items-start justify-between gap-3">
                <p className="text-[0.6rem] leading-4 text-cream/35" aria-live="polite">
                  {status || "Yours stays in the sky until you pop it. Nothing is saved or shared."}
                </p>
                <span className="shrink-0 text-[0.5rem] font-semibold uppercase tracking-[0.16em] text-cream/25">
                  7 + yours
                </span>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
