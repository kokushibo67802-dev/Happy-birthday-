import type { CSSProperties } from "react";
import { images } from "../data";
import { useCountdown } from "../lib/hooks";
import {
  ArrowDown,
  ArrowUpRight,
  BalloonIcon,
  FlowerIcon,
  GlassIcon,
  Heart,
  QuoteMark,
  Sparkle,
  Squiggle,
  Tulip,
} from "./Decor";
import { TiltCard } from "./TiltCard";
import { Marquee, Tape } from "./ui";

const miniBalloons = [
  {
    className: "-right-2 top-14 sm:-right-5 lg:-right-3",
    w: "42px",
    main: "#c9828d",
    light: "#efc5c5",
    dark: "#87414f",
    delay: "-1s",
  },
  {
    className: "-left-4 top-36 sm:-left-7 lg:-left-6",
    w: "30px",
    main: "#d3aa6e",
    light: "#f4e0ba",
    dark: "#92703d",
    delay: "-3s",
  },
  {
    className: "right-10 -bottom-8",
    w: "34px",
    main: "#9fb29a",
    light: "#dbe3d1",
    dark: "#5d7562",
    delay: "-2s",
  },
];

function MiniBalloon({
  w,
  main,
  light,
  dark,
  delay,
  className = "",
}: {
  w: string;
  main: string;
  light: string;
  dark: string;
  delay: string;
  className?: string;
}) {
  return (
    <div className={`pointer-events-none absolute z-20 ${className}`} aria-hidden="true">
      <div className="float-soft" style={{ animationDelay: delay }}>
        <span
          className="balloon__body block"
          style={
            {
              "--w": w,
              "--b-main": main,
              "--b-light": light,
              "--b-dark": dark,
              width: w,
              height: `calc(${w} * 1.16)`,
            } as CSSProperties
          }
        >
          <span className="balloon__knot" />
        </span>
        <svg
          viewBox="0 0 40 70"
          className="mx-auto -mt-px w-6 text-ink/25"
          fill="none"
          aria-hidden="true"
        >
          <path d="M20 0c8 14-12 24 0 38s-8 20 2 32" stroke="currentColor" strokeWidth="1" />
        </svg>
      </div>
    </div>
  );
}

function Countdown() {
  const { days, hours, minutes, seconds, isToday } = useCountdown(10, 14);
  const parts = [
    { label: "days", value: days },
    { label: "hrs", value: hours },
    { label: "min", value: minutes },
    { label: "sec", value: seconds },
  ];

  return (
    <div className="mt-9 border-t border-ink/10 pt-6">
      <div className="flex flex-wrap items-center gap-x-7 gap-y-5">
        <div className="flex items-center gap-3">
          <span className="display text-[2.6rem] leading-none text-ink">14</span>
          <span className="flex flex-col text-[0.6rem] font-semibold uppercase leading-[1.5] tracking-[0.22em] text-ink/55">
            <span>November</span>
            <span className="text-rose-deep">her day</span>
          </span>
        </div>
        <span className="hidden h-9 w-px bg-ink/10 sm:block" aria-hidden="true" />
        <div>
          <p className="text-[0.58rem] font-semibold uppercase tracking-[0.22em] text-ink/45">
            {isToday ? "The day is here" : "Counting down to the celebration"}
          </p>
          {isToday ? (
            <p className="script mt-1 text-[1.35rem] leading-none text-rose-deep">
              Happiest birthday, Mrunal.
            </p>
          ) : (
            <div className="mt-2 flex items-start gap-3.5" aria-live="polite">
              {parts.map((part) => (
                <div key={part.label} className="min-w-[2.1rem]">
                  <span className="display block text-[1.5rem] leading-none tabular-nums text-ink">
                    {String(part.value).padStart(2, "0")}
                  </span>
                  <span className="mt-1 block text-[0.5rem] font-semibold uppercase tracking-[0.18em] text-ink/40">
                    {part.label}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function Hero() {
  return (
    <section id="top" className="texture-soft relative overflow-hidden pb-16 pt-28 md:pt-32 lg:pb-20">
      <div
        className="pointer-events-none absolute -right-40 -top-24 h-[38rem] w-[38rem] rounded-full bg-[radial-gradient(circle,rgba(237,213,207,0.55),transparent_65%)] blur-2xl"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute -left-32 bottom-10 h-[26rem] w-[26rem] rounded-full bg-[radial-gradient(circle,rgba(170,183,164,0.35),transparent_68%)] blur-2xl"
        aria-hidden="true"
      />
      <Sparkle className="twinkle absolute left-[46%] top-24 hidden h-4 w-4 text-rose/50 md:block" />
      <Sparkle className="twinkle absolute right-[6%] top-[24rem] h-3 w-3 text-gold/60 [animation-delay:1.6s]" />
      <Sparkle className="twinkle absolute bottom-40 left-[8%] hidden h-3 w-3 text-sage-deep/40 [animation-delay:.8s] lg:block" />

      <div className="page-shell relative">
        <div className="mb-10 flex flex-wrap items-center justify-between gap-3 border-b border-ink/10 pb-4 text-[0.58rem] font-semibold uppercase tracking-[0.24em] text-ink/45 md:mb-14">
          <span className="inline-flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-rose" />
            A birthday archive — volume one
          </span>
          <span>For Mrunal · 14 November</span>
        </div>

        <div className="grid items-center gap-14 lg:grid-cols-[1.03fr_0.97fr] lg:gap-10 xl:gap-16">
          {/* ---------- left ---------- */}
          <div className="relative z-10 max-w-[37rem]">
            <p className="reveal eyebrow text-sage-deep">
              <Sparkle className="h-3.5 w-3.5 text-rose" />
              A little celebration, made with care
            </p>

            <h1 className="reveal mt-6 text-ink" style={{ "--reveal-delay": "80ms" } as CSSProperties}>
              <span className="script block text-[clamp(1.7rem,3.6vw,2.6rem)] leading-none text-rose-deep">
                Happy birthday,
              </span>
              <span className="display mt-2 block text-[clamp(3.6rem,8.2vw,7rem)]">
                Mrunal
                <span className="text-rose">.</span>
              </span>
            </h1>

            <div className="reveal relative mt-6 max-w-[30rem]" style={{ "--reveal-delay": "160ms" } as CSSProperties}>
              <Squiggle className="absolute -left-1 -top-4 h-3 w-24 text-rose/35" />
              <p className="text-[0.95rem] leading-8 text-ink/65">
                We haven't met yet. But some people are an entire atmosphere — tulips and lilies, water in a
                clear glass, something warm from the oven, and a film that still knows how to end. This little
                corner of the internet is for your day.
              </p>
            </div>

            <div
              className="reveal mt-8 flex flex-wrap items-center gap-3"
              style={{ "--reveal-delay": "240ms" } as CSSProperties}
            >
              <a href="#celebrate" className="btn btn-dark">
                <BalloonIcon className="h-4 w-4" />
                Release a birthday balloon
              </a>
              <a href="#note" className="btn btn-outline">
                A note from Arush
                <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
            </div>

            <div className="reveal" style={{ "--reveal-delay": "300ms" } as CSSProperties}>
              <Countdown />
            </div>

            <div className="mt-7 flex flex-wrap items-center gap-x-6 gap-y-3 text-[0.66rem] font-medium text-ink/50">
              <span className="inline-flex items-center gap-2">
                <FlowerIcon className="h-4 w-4 text-rose" />
                Tulips &amp; lilies
              </span>
              <span className="inline-flex items-center gap-2">
                <GlassIcon className="h-4 w-4 text-sage-deep" />
                Water, always
              </span>
              <span className="inline-flex items-center gap-2">
                <Heart className="h-4 w-4 text-rose-deep/70" />
                A very good year ahead
              </span>
            </div>
          </div>

          {/* ---------- right / portrait ---------- */}
          <div
            className="reveal relative mx-auto w-full max-w-[29rem] lg:mr-2 lg:max-w-[31rem] xl:max-w-[33rem]"
            style={{ "--reveal-delay": "180ms" } as CSSProperties}
          >
            <div className="relative pb-10 pl-2 pr-2 sm:pb-14">
              <div
                className="absolute inset-x-6 top-8 bottom-16 rotate-[3.2deg] rounded-[999px_999px_1.8rem_1.8rem] border border-ink/15 bg-paper-2"
                aria-hidden="true"
              />
              <div
                className="absolute inset-x-2 top-3 bottom-20 -rotate-[2.4deg] rounded-[999px_999px_1.8rem_1.8rem] bg-blush/60"
                aria-hidden="true"
              />

              <TiltCard
                className="relative z-10 overflow-hidden rounded-[999px_999px_1.6rem_1.6rem] bg-paper-2 shadow-[0_50px_90px_-50px_rgba(29,43,37,0.65)] ring-1 ring-ink/10"
                maxTilt={4}
              >
                <div className="relative aspect-[4/4.9] w-full overflow-hidden">
                  <img
                    src={images.portrait}
                    alt="Mrunal standing in a sunlit garden, wearing a light top and jeans."
                    className="h-full w-full object-cover object-[62%_36%] saturate-[0.92] contrast-[1.02]"
                    loading="eager"
                    decoding="async"
                  />
                  <div
                    className="absolute inset-0 bg-[linear-gradient(180deg,rgba(247,243,234,0.18),transparent_30%,transparent_62%,rgba(20,38,32,0.6))]"
                    aria-hidden="true"
                  />
                  <div
                    className="absolute inset-0 mix-blend-soft-light"
                    style={{
                      background:
                        "radial-gradient(circle at 68% 30%, rgba(255,241,210,0.5), transparent 46%), radial-gradient(circle at 20% 80%, rgba(185,116,127,0.24), transparent 50%)",
                    }}
                    aria-hidden="true"
                  />

                  <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-5 sm:p-6">
                    <div className="text-cream">
                      <p className="script text-[1.65rem] leading-none sm:text-[1.9rem]">Mrunal</p>
                      <p className="mt-2 text-[0.53rem] font-semibold uppercase tracking-[0.22em] text-cream/70">
                        the birthday girl · 14.11
                      </p>
                    </div>
                    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-cream/30 bg-cream/10 text-cream backdrop-blur-sm">
                      <FlowerIcon className="h-4 w-4" />
                    </span>
                  </div>
                </div>
                <div className="tilt__glare" aria-hidden="true" />
              </TiltCard>

              <Tape className="-left-3 top-16 -rotate-6 sm:-left-5" label="a little celebration" />
              <div className="absolute -right-1 top-4 z-20 rotate-6 rounded-xl border border-ink/10 bg-cream px-3 py-2 text-center shadow-[0_14px_30px_-18px_rgba(29,43,37,0.6)] sm:-right-4">
                <span className="block font-display text-lg leading-none text-ink">14</span>
                <span className="mt-0.5 block text-[0.48rem] font-bold uppercase tracking-[0.2em] text-rose-deep">
                  Nov
                </span>
              </div>

              {/* water keepsake */}
              <div className="absolute -bottom-1 left-0 z-20 hidden w-[9.5rem] -rotate-[5deg] rounded-xl bg-cream p-2.5 shadow-[0_26px_40px_-26px_rgba(29,43,37,0.6)] ring-1 ring-ink/10 sm:block">
                <div className="h-20 overflow-hidden rounded-lg">
                  <img
                    src={images.water}
                    alt="A clear glass of water with a slice of lemon in warm sunlight."
                    className="h-full w-full object-cover"
                    loading="lazy"
                    decoding="async"
                  />
                </div>
                <div className="flex items-center justify-between gap-2 px-1 pb-0.5 pt-2">
                  <span className="text-[0.5rem] font-bold uppercase tracking-[0.16em] text-ink/60">
                    her order
                  </span>
                  <GlassIcon className="h-3.5 w-3.5 text-sage-deep" />
                </div>
                <p className="px-1 pb-1 font-serif text-[0.95rem] italic leading-none text-ink">water, no notes.</p>
              </div>

              {/* quote keepsake */}
              <div className="absolute -right-2 bottom-16 z-20 hidden w-[13.5rem] rotate-[3deg] rounded-xl border border-ink/10 bg-ink p-4 text-cream shadow-[0_26px_44px_-26px_rgba(29,43,37,0.8)] md:block lg:-right-5">
                <QuoteMark className="h-3.5 w-3.5 text-blush/70" />
                <p className="mt-2 font-serif text-[1.05rem] italic leading-snug text-cream/90">
                  Some people are a whole atmosphere.
                </p>
                <span className="mt-3 block text-[0.48rem] font-semibold uppercase tracking-[0.2em] text-cream/40">
                  noted from a distance
                </span>
              </div>

              {/* rotating seal */}
              <div className="absolute -right-6 top-24 z-20 hidden h-24 w-24 xl:block">
                <div className="spin-slow absolute inset-0">
                  <svg viewBox="0 0 100 100" className="h-full w-full" aria-hidden="true">
                    <defs>
                      <path id="sealPath" d="M50,50 m-36,0 a36,36 0 1,1 72,0 a36,36 0 1,1 -72,0" />
                    </defs>
                    <circle cx="50" cy="50" r="49" fill="#fcf9f2" stroke="rgba(29,43,37,0.16)" />
                    <circle cx="50" cy="50" r="30" fill="none" stroke="rgba(29,43,37,0.12)" />
                    <text fill="#8c4552" fontSize="7.2" fontWeight="600" letterSpacing="2.6">
                      <textPath href="#sealPath" startOffset="0%">
                        HAPPY BIRTHDAY · MRUNAL · 14 NOV ·
                      </textPath>
                    </text>
                  </svg>
                </div>
                <span className="absolute inset-0 grid place-items-center text-rose-deep">
                  <BalloonIcon className="h-6 w-6" />
                </span>
              </div>

              <Tulip className="absolute -bottom-6 right-10 z-20 hidden h-24 w-auto rotate-[7deg] sm:block" />

              {miniBalloons.map((b, i) => (
                <MiniBalloon key={i} {...b} />
              ))}
            </div>

            <div className="mt-1 flex items-center justify-between px-2 text-[0.56rem] font-semibold uppercase tracking-[0.2em] text-ink/40">
              <span className="inline-flex items-center gap-2">
                <span className="h-px w-6 bg-ink/25" />
                portrait no. 01
              </span>
              <span className="inline-flex items-center gap-1.5">
                loved from afar
                <Heart className="h-3 w-3 text-rose" />
              </span>
            </div>
          </div>
        </div>

        <a
          href="#celebrate"
          className="group mt-14 inline-flex items-center gap-3 text-[0.58rem] font-semibold uppercase tracking-[0.24em] text-ink/45 transition hover:text-ink"
        >
          <span className="grid h-8 w-8 place-items-center rounded-full border border-ink/20 transition group-hover:border-ink/50">
            <ArrowDown className="h-3.5 w-3.5" />
          </span>
          Scroll to unwrap
        </a>
      </div>

      <div className="mt-12 hidden border-y border-ink/10 bg-cream/60 py-4 text-[0.6rem] font-semibold uppercase tracking-[0.22em] text-ink/45 sm:block">
        <Marquee
          items={[
            "Tulips & lilies",
            "Water, always",
            "Something freshly baked",
            "10 Things I Hate About You",
            "14 November",
            "A very good birthday",
          ]}
        />
      </div>
    </section>
  );
}
